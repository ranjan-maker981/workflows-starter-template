import { useState } from 'react';
export default function TopBar({ title, user, onLogout }) {
const [showMenu, setShowMenu] = useState(false);
return (
<header className="bg-white border-b border-gray-100 px-4 md:px-6 py-3 flex items-center justify-between sticky top-0 z-20">
<div className="ml-10 md:ml-0">
<h2 className="text-lg font-semibold text-dk-dark">{title}</h2>
</div>
<div className="flex items-center gap-4">
{/* Notifications placeholder */}
<button className="relative p-2 hover:bg-gray-50 rounded-lg">
<span className="text-lg">🔔</span>
<span className="absolute top-1 right-1 w-2 h-2 bg-dk-primary rounded-full"></span>
</button>
{/* User Menu */}
<div className="relative">
<button onClick={() => setShowMenu(!showMenu)}
className="flex items-center gap-2 hover:bg-gray-50 rounded-lg px-3 py-1.5">
<div className="w-8 h-8 bg-dk-primary/10 text-dk-primary rounded-full flex items-center justify-center font-semibold text-sm">
{(user?.name || 'U').charAt(0)}
</div>
<div className="hidden md:block text-left">
<p className="text-sm font-medium">{user?.name}</p>
<p className="text-xs text-gray-400 capitalize">{user?.role}</p>
</div>
</button>
{showMenu && (
<>
<div className="fixed inset-0 z-10" onClick={() => setShowMenu(false)} />
<div className="absolute right-0 top-full mt-1 w-48 bg-white rounded-xl shadow-lg border border-gray-100 z-20 py-2">
<div className="px-4 py-2 border-b border-gray-50">
<p className="text-sm font-medium">{user?.name}</p>
<p className="text-xs text-gray-400">{user?.phone}</p>
</div>
<button onClick={onLogout}
className="w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-red-50">
Logout
</button>
</div>
</>
)}
</div>
</div>
</header>
);
}