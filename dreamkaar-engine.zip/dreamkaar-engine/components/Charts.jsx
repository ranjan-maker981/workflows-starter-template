import {
BarChart, Bar, LineChart, Line, PieChart, Pie, Cell,
XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend, AreaChart, Area
} from 'recharts';
const COLORS = ['#E63946', '#1D3557', '#F4A261', '#10B981', '#3B82F6', '#8B5CF6', '#EC4899', '#F59E0B'];
export function BarChartWidget({ data, xKey, yKey, title, color = '#E63946', height = 300 }) {
return (
<div className="card">
{title && <h3 className="text-sm font-semibold text-gray-600 mb-4">{title}</h3>}
<ResponsiveContainer width="100%" height={height}>
<BarChart data={data}>
<CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
<XAxis dataKey={xKey} tick={{ fontSize: 12 }} />
<YAxis tick={{ fontSize: 12 }} />
<Tooltip />
<Bar dataKey={yKey} fill={color} radius={[4, 4, 0, 0]} />
</BarChart>
</ResponsiveContainer>
</div>
);
}
export function LineChartWidget({ data, xKey, lines, title, height = 300 }) {
return (
<div className="card">
{title && <h3 className="text-sm font-semibold text-gray-600 mb-4">{title}</h3>}
<ResponsiveContainer width="100%" height={height}>
<LineChart data={data}>
<CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
<XAxis dataKey={xKey} tick={{ fontSize: 12 }} />
<YAxis tick={{ fontSize: 12 }} />
<Tooltip />
<Legend />
{lines.map((line, i) => (
<Line key={line.key} type="monotone" dataKey={line.key} name={line.label}
stroke={COLORS[i]} strokeWidth={2} dot={{ r: 3 }} />
))}
</LineChart>
</ResponsiveContainer>
</div>
);
}
export function PieChartWidget({ data, nameKey, valueKey, title, height = 300 }) {
return (
<div className="card">
{title && <h3 className="text-sm font-semibold text-gray-600 mb-4">{title}</h3>}
<ResponsiveContainer width="100%" height={height}>
<PieChart>
<Pie data={data} dataKey={valueKey} nameKey={nameKey} cx="50%" cy="50%"
outerRadius={100} innerRadius={50} paddingAngle={2}>
{data.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
</Pie>
<Tooltip />
<Legend />
</PieChart>
</ResponsiveContainer>
</div>
);
}
export function AreaChartWidget({ data, xKey, yKey, title, color = '#E63946', height = 300 }) {
return (
<div className="card">
{title && <h3 className="text-sm font-semibold text-gray-600 mb-4">{title}</h3>}
<ResponsiveContainer width="100%" height={height}>
<AreaChart data={data}>
<CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
<XAxis dataKey={xKey} tick={{ fontSize: 12 }} />
<YAxis tick={{ fontSize: 12 }} />
<Tooltip />
<Area type="monotone" dataKey={yKey} stroke={color} fill={color} fillOpacity={0.1} />
</AreaChart>
</ResponsiveContainer>
</div>
);
}
export function StatCard({ label, value, change, changeType, icon, suffix = '' }) {
return (
<div className="stat-card">
<div className="flex items-center justify-between">
<span className="text-2xl">{icon}</span>
{change !== undefined && (
<span className={changeType === 'up' ? 'stat-change-up' : 'stat-change-down'}>
{changeType === 'up' ? '↑' : '↓'} {change}%
</span>
)}
</div>
<div className="mt-3">
<div className="stat-value">{value}{suffix}</div>
<div className="stat-label">{label}</div>
</div>
</div>
);
}