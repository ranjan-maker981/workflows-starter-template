import { useState, useEffect, createContext, useContext } from 'react';
const ToastContext = createContext(null);
export function useToast() {
return useContext(ToastContext);
}
export function ToastProvider({ children }) {
const [toasts, setToasts] = useState([]);
function addToast(message, type = 'success', duration = 3000) {
const id = Date.now();
setToasts(prev => [...prev, { id, message, type }]);
setTimeout(() => setToasts(prev => prev.filter(t => t.id !== id)), duration);
}
return (
<ToastContext.Provider value={{ addToast }}>
{children}
<div className="fixed bottom-4 right-4 z-50 space-y-2">
{toasts.map(t => (
<div key={t.id} className={`toast ${
t.type === 'success' ? 'bg-dk-success' :
t.type === 'error' ? 'bg-dk-danger' :
t.type === 'warning' ? 'bg-dk-warning' : 'bg-dk-info'
}`}>
{t.message}
</div>
))}
</div>
</ToastContext.Provider>
);
}