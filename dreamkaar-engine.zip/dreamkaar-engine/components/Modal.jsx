import { useEffect } from 'react';
export default function Modal({ isOpen, onClose, title, children, size = 'md' }) {
useEffect(() => {
if (isOpen) document.body.style.overflow = 'hidden';
else document.body.style.overflow = '';
return () => { document.body.style.overflow = ''; };
}, [isOpen]);
if (!isOpen) return null;
const sizes = {
sm: 'max-w-md', md: 'max-w-lg', lg: 'max-w-2xl', xl: 'max-w-4xl', full: 'max-w-6xl',
};
return (
<div className="fixed inset-0 z-50 flex items-center justify-center p-4">
<div className="fixed inset-0 bg-black/50" onClick={onClose} />
<div className={`relative bg-white rounded-2xl shadow-xl w-full ${sizes[size]} max-h-[90vh] overflow-y-auto animate-fade-in`}>
<div className="flex items-center justify-between p-5 border-b border-gray-100">
<h3 className="text-lg font-semibold">{title}</h3>
<button onClick={onClose} className="p-1 hover:bg-gray-100 rounded-lg text-gray-400">✕</button>
</div>
<div className="p-5">{children}</div>
</div>
</div>
);
}