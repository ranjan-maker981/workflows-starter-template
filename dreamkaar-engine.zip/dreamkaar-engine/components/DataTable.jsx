import { useState } from 'react';
export default function DataTable({ columns, data, onRowClick, emptyMessage = 'No data found' }) {
const [sortCol, setSortCol] = useState(null);
const [sortDir, setSortDir] = useState('asc');
const [search, setSearch] = useState('');
function handleSort(col) {
if (sortCol === col) setSortDir(d => d === 'asc' ? 'desc' : 'asc');
else { setSortCol(col); setSortDir('asc'); }
}
let filtered = data || [];
if (search) {
const s = search.toLowerCase();
filtered = filtered.filter(row =>
columns.some(col => String(row[col.key] || '').toLowerCase().includes(s))
);
}
if (sortCol) {
filtered = [...filtered].sort((a, b) => {
const av = a[sortCol] || '', bv = b[sortCol] || '';
const cmp = typeof av === 'number' ? av - bv : String(av).localeCompare(String(bv));
return sortDir === 'asc' ? cmp : -cmp;
});
}
return (
<div>
<div className="mb-4">
<input type="text" placeholder="Search..." className="input-field max-w-xs"
value={search} onChange={e => setSearch(e.target.value)} />
</div>
<div className="overflow-x-auto rounded-xl border border-gray-100">
<table className="w-full">
<thead>
<tr className="table-header">
{columns.map(col => (
<th key={col.key} className="px-4 py-3 cursor-pointer hover:bg-gray-100"
onClick={() => col.sortable !== false && handleSort(col.key)}>
<div className="flex items-center gap-1">
{col.label}
{sortCol === col.key && <span>{sortDir === 'asc' ? '↑' : '↓'}</span>}
</div>
</th>
))}
</tr>
</thead>
<tbody>
{filtered.length === 0 ? (
<tr>
<td colSpan={columns.length} className="text-center py-12 text-gray-400">
{emptyMessage}
</td>
</tr>
) : (
filtered.map((row, i) => (
<tr key={row.id || i}
className={`hover:bg-gray-50 transition-colors ${onRowClick ? 'cursor-pointer' : ''}`}
onClick={() => onRowClick?.(row)}>
{columns.map(col => (
<td key={col.key} className="table-cell">
{col.render ? col.render(row[col.key], row) : row[col.key]}
</td>
))}
</tr>
))
)}
</tbody>
</table>
</div>
<div className="mt-3 text-sm text-gray-400">
{filtered.length} of {(data || []).length} records
</div>
</div>
);
}