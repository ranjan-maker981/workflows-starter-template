import { useAuth } from '../pages/_app';
import Sidebar from './Sidebar';
import TopBar from './TopBar';
import { useRouter } from 'next/router';
import { useEffect } from 'react';
export default function Layout({ children, title = 'Dashboard' }) {
const { user, loading, logout } = useAuth();
const router = useRouter();
useEffect(() => {
if (!loading && !user) router.push('/login');
}, [user, loading]);
if (loading) {
return (
<div className="min-h-screen flex items-center justify-center bg-dk-light">
<div className="animate-pulse text-dk-primary text-lg font-semibold">Loading...</div>
</div>
);
}
if (!user) return null;
return (
<div className="min-h-screen bg-dk-light flex">
<Sidebar role={user.role} />
<div className="flex-1 flex flex-col min-h-screen ml-0 md:ml-64">
<TopBar title={title} user={user} onLogout={logout} />
<main className="flex-1 p-4 md:p-6 overflow-auto">
{children}
</main>
</div>
</div>
);
}