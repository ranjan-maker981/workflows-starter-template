import Link from 'next/link';
import { useRouter } from 'next/router';
import { useState } from 'react';
const MENU = {
admin: [
{ label: 'Dashboard', href: '/admin', icon: '📊' },
{ label: 'Leads', href: '/admin/leads', icon: '👥' },
{ label: 'Pipeline', href: '/admin/pipeline', icon: '🔀' },
{ label: 'Deals', href: '/admin/deals', icon: '🤝' },
{ label: 'DSA Network', href: '/admin/dsa', icon: '🌐' },
{ label: 'Dealers', href: '/admin/dealers', icon: '🏪' },
{ label: 'Finance', href: '/admin/finance', icon: '🏦' },
{ label: 'Insurance', href: '/admin/insurance', icon: '🛡️' },
{ label: 'Fleet', href: '/admin/fleet', icon: '🚛' },
{ label: 'MSME', href: '/admin/msme', icon: '🏭' },
{ label: 'HNI', href: '/admin/hni', icon: '💎' },
{ label: 'Market Intel', href: '/admin/market-intelligence', icon: '📈' },
{ label: 'Discount Engine', href: '/admin/discount-engine', icon: '🧠' },
{ label: 'Documents', href: '/admin/documents', icon: '📄' },
{ label: 'Payments', href: '/admin/payments', icon: '💰' },
{ label: 'Referrals', href: '/admin/referrals', icon: '🎁' },
{ label: 'Post-Sale', href: '/admin/post-sale', icon: '🔔' },
{ label: 'Analytics', href: '/admin/analytics', icon: '📉' },
{ label: 'Reports', href: '/admin/reports', icon: '📋' },
{ label: 'Settings', href: '/admin/settings', icon: '⚙️' },
{ label: 'Users', href: '/admin/users', icon: '👤' },
],
sales: [
{ label: 'Dashboard', href: '/sales', icon: '📊' },
{ label: 'My Leads', href: '/sales/my-leads', icon: '👥' },
{ label: 'Tasks', href: '/sales/tasks', icon: '✅' },
{ label: 'Quotes', href: '/sales/quotes', icon: '📝' },
{ label: 'Performance', href: '/sales/performance', icon: '🏆' },
],
dsa: [
{ label: 'Dashboard', href: '/dsa', icon: '📊' },
{ label: 'Submit Lead', href: '/dsa/submit-lead', icon: '➕' },
{ label: 'My Leads', href: '/dsa/my-leads', icon: '👥' },
{ label: 'Commissions', href: '/dsa/commissions', icon: '💰' },
{ label: 'Discount Intel', href: '/dsa/discount-intel', icon: '🧠' },
{ label: 'Leaderboard', href: '/dsa/leaderboard', icon: '🏆' },
],
dealer: [
{ label: 'Dashboard', href: '/dealer', icon: '📊' },
{ label: 'Inventory', href: '/dealer/inventory', icon: '📦' },
{ label: 'Orders', href: '/dealer/orders', icon: '📋' },
{ label: 'Invoices', href: '/dealer/invoices', icon: '🧾' },
{ label: 'Performance', href: '/dealer/performance', icon: '🏆' },
],
nbfc: [
{ label: 'Dashboard', href: '/nbfc', icon: '📊' },
{ label: 'Applications', href: '/nbfc/applications', icon: '📋' },
{ label: 'Disbursements', href: '/nbfc/disbursements', icon: '💰' },
],
fleet: [
{ label: 'Dashboard', href: '/fleet', icon: '📊' },
{ label: 'New Inquiry', href: '/fleet/inquiry', icon: '➕' },
{ label: 'Orders', href: '/fleet/orders', icon: '📋' },
{ label: 'TCO Calculator', href: '/fleet/tco-calculator', icon: '🧮' },
],
customer: [
{ label: 'Dashboard', href: '/customer', icon: '📊' },
{ label: 'Track Order', href: '/customer/track-order', icon: '🚗' },
{ label: 'Documents', href: '/customer/documents', icon: '📄' },
{ label: 'Payments', href: '/customer/payments', icon: '💰' },
{ label: 'Referral', href: '/customer/referral', icon: '🎁' },
],
};
export default function Sidebar({ role }) {
const router = useRouter();
const [open, setOpen] = useState(false);
const items = MENU[role] || [];
return (
<>
{/* Mobile toggle */}
<button onClick={() => setOpen(!open)}
className="md:hidden fixed top-3 left-3 z-50 bg-white p-2 rounded-lg shadow-md">
<span className="text-xl">{open ? '✕' : '☰'}</span>
</button>
{/* Overlay */}
{open && <div className="md:hidden fixed inset-0 bg-black/50 z-30" onClick={() => setOpen(false)} />}
{/* Sidebar */}
<aside className={`fixed top-0 left-0 h-full w-64 bg-white border-r border-gray-100 z-40 
transform transition-transform duration-200 overflow-y-auto
${open ? 'translate-x-0' : '-translate-x-full'} md:translate-x-0`}>
<div className="p-5 border-b border-gray-100">
<h1 className="text-2xl font-bold">
Dream<span className="text-dk-primary">Kaar</span>
</h1>
<p className="text-xs text-gray-400 mt-1">Engine v1.0</p>
</div>
<nav className="p-3 space-y-1">
{items.map(item => {
const isActive = router.pathname === item.href ||
(item.href !== `/${role}` && router.pathname.startsWith(item.href));
return (
<Link key={item.href} href={item.href}
className={isActive ? 'sidebar-link-active' : 'sidebar-link'}
onClick={() => setOpen(false)}>
<span className="text-lg">{item.icon}</span>
<span>{item.label}</span>
</Link>
);
})}
</nav>
</aside>
</>
);
}