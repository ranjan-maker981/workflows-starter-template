# DreamKaar Engine 🚗

**Full-stack business operating system for DreamKaar — India's intelligent vehicle sales platform.**

## Tech Stack
- **Next.js 14** (Pages Router, full-stack)
- **SQLite** (better-sqlite3) — zero-config database, ready for PostgreSQL migration
- **Tailwind CSS** — responsive, mobile-first
- **Firebase Auth** — phone OTP login
- **Recharts** — charts & analytics
- **@react-pdf/renderer** — PDF quote generation
- **Razorpay** — payment links
- **PWA** — installable on mobile for field team

## Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Configure environment
cp .env.local .env.local.example
# Edit .env.local with your credentials

# 3. Start development server
npm run dev

# 4. Seed the database (in a separate terminal)
npm run seed
# OR visit: http://localhost:3000/api/seed
```

## Environment Variables (.env.local)

```
NEXT_PUBLIC_FIREBASE_API_KEY=your_key
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=your_domain
NEXT_PUBLIC_FIREBASE_PROJECT_ID=your_project
JWT_SECRET=your_jwt_secret_min_32_chars
RAZORPAY_KEY_ID=rzp_test_...
RAZORPAY_KEY_SECRET=...
WHATSAPP_API_TOKEN=...
WHATSAPP_PHONE_ID=...
NEXTAUTH_URL=https://engine.dreamkaar.com
```

## Folder Structure

```
dreamkaar-engine/
├── lib/              # Core business logic
│   ├── db.js         # SQLite database & all table schemas
│   ├── auth.js       # JWT authentication middleware
│   ├── roles.js      # Role-based access control (7 roles)
│   ├── discount-engine.js   # AI discount prediction
│   ├── onroad-calculator.js # On-road price calculator
│   ├── pdf-generator.js     # PDF quote generation
│   ├── whatsapp.js          # WhatsApp Business API
│   ├── razorpay.js          # Payment links
│   └── seed-data/    # Vehicle & partner databases
├── pages/
│   ├── api/          # All API routes
│   ├── admin/        # Admin portal (full access)
│   ├── sales/        # Sales team portal
│   ├── dsa/          # DSA (agent) portal
│   ├── dealer/       # Dealer portal
│   ├── nbfc/         # Finance partner portal
│   ├── fleet/        # Fleet/corporate portal
│   ├── customer/     # Customer portal
│   └── embed/        # Embeddable widgets
├── components/       # Reusable UI components
└── styles/           # Global CSS
```

## 7 Stakeholder Portals

| Role | URL | Description |
|------|-----|-------------|
| Admin | /admin | Full god-mode access |
| Sales | /sales | Lead management, quotes |
| DSA | /dsa | Agent portal, commissions |
| Dealer | /dealer | Inventory, orders |
| NBFC | /nbfc | Loan applications |
| Fleet | /fleet | Bulk inquiries, TCO |
| Customer | /customer | Order tracking |

## Deployment on engine.dreamkaar.com

### Option A: Vercel (Recommended)
1. Push to GitHub
2. Connect repo to Vercel
3. Add environment variables
4. Deploy → set custom domain to `engine.dreamkaar.com`

### Option B: VPS/Server
```bash
npm run build
npm start
# Use nginx reverse proxy to port 3000
```

## Default Admin Login
After seeding (`/api/seed`), login with:
- Phone: any registered phone number
- OTP via Firebase
- First user auto-assigned admin role
