/** @type {import('next').NextConfig} */
const nextConfig = {
reactStrictMode: true,
headers: async () => [
{
source: '/embed/:path*',
headers: [
{ key: 'X-Frame-Options', value: 'ALLOWALL' },
{ key: 'Content-Security-Policy', value: 'frame-ancestors *' },
],
},
],
webpack: (config) => {
config.externals = [...(config.externals || []), 'better-sqlite3'];
return config;
},
};
module.exports = nextConfig;