import Layout from '../../components/Layout';
export default function Referrals() {
return <Layout title="Referral Program"><div className="card"><p className="text-gray-400 text-center py-12">Referral codes are auto-generated when a deal is marked "delivered". Track referral chains and payouts here.</p></div></Layout>;
}