import Layout from '../../components/Layout';
export default function HNI() {
return <Layout title="HNI Management"><div className="card"><p className="text-gray-400 text-center py-12">Leads with budget &gt; ₹25L or premium brand interest are auto-tagged HNI. Separate pipeline with concierge workflow.</p></div></Layout>;
}