import { useState, useEffect } from 'react';
import Layout from '../../components/Layout';
import DataTable from '../../components/DataTable';
export default function AdminDealers() {
const [dealers, setDealers] = useState([]);
useEffect(() => { fetch('/api/dealers').then(r=>r.json()).then(d=>setDealers(d.dealers||[])); }, []);
async function updateStatus(id, status) {
await fetch(`/api/dealers/${id}`, { method:'PATCH', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ status }) });
setDealers(prev => prev.map(d => d.id === id ? { ...d, status } : d));
}
const columns = [
{ key: 'name', label: 'Dealership', render: v => <span className="font-medium">{v}</span> },
{ key: 'brand', label: 'Brand' },
{ key: 'city', label: 'City' },
{ key: 'contact_person', label: 'Contact' },
{ key: 'phone', label: 'Phone' },
{ key: 'total_orders', label: 'Orders' },
{ key: 'total_delivered', label: 'Delivered' },
{ key: 'reliability_score', label: 'Rating', render: v => v ? `${v}/5` : '-' },
{ key: 'status', label: 'Status', render: (v, row) => (
<select className="select-field text-xs py-1 w-auto" value={v} onChange={e=>updateStatus(row.id, e.target.value)}>
<option value="pending">Pending</option><option value="approved">Approved</option><option value="suspended">Suspended</option>
</select>
)},
];
return (
<Layout title="Dealer Management">
<DataTable columns={columns} data={dealers} emptyMessage="No dealers registered" />
</Layout>
);
}