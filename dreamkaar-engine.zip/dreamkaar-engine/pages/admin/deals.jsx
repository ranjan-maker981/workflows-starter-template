import { useState, useEffect } from 'react';
import Layout from '../../components/Layout';
import DataTable from '../../components/DataTable';
import Modal from '../../components/Modal';
export default function AdminDeals() {
const [deals, setDeals] = useState([]);
const [loading, setLoading] = useState(true);
useEffect(() => { fetchDeals(); }, []);
async function fetchDeals() {
const res = await fetch('/api/deals');
const data = await res.json();
setDeals(data.deals || []);
setLoading(false);
}
const columns = [
{ key: 'customer_name', label: 'Customer', render: v => <span className="font-medium">{v}</span> },
{ key: 'model_name', label: 'Model' },
{ key: 'variant_name', label: 'Variant' },
{ key: 'on_road_price', label: 'On-Road (₹)', render: v => v ? `₹${v.toLocaleString('en-IN')}` : '-' },
{ key: 'customer_discount', label: 'Discount', render: v => v ? `₹${v.toLocaleString('en-IN')}` : '-' },
{ key: 'dk_commission', label: 'DK Commission', render: v => v ? `₹${v.toLocaleString('en-IN')}` : '-' },
{ key: 'status', label: 'Status', render: v => <DealStatusBadge status={v} /> },
{ key: 'dealer_name', label: 'Dealer' },
{ key: 'created_at', label: 'Date', render: v => v ? new Date(v).toLocaleDateString('en-IN') : '-' },
];
return (
<Layout title="Deals">
<div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
<StatMini label="Total Deals" value={deals.length} />
<StatMini label="Active" value={deals.filter(d => !['delivered','cancelled'].includes(d.status)).length} />
<StatMini label="Delivered" value={deals.filter(d => d.status === 'delivered').length} />
<StatMini label="Total Revenue" value={`₹${deals.reduce((s,d) => s + (d.dk_commission || 0), 0).toLocaleString('en-IN')}`} />
</div>
<DataTable columns={columns} data={deals} emptyMessage="No deals yet" />
</Layout>
);
}
function DealStatusBadge({ status }) {
const colors = {
booked: 'badge-info', finance_applied: 'badge-warning', finance_approved: 'badge-success',
invoice_generated: 'badge-info', vehicle_allocated: 'badge-info',
dispatched: 'badge-warning', delivered: 'badge-success', cancelled: 'badge-danger',
};
return <span className={colors[status] || 'badge-neutral'} style={{textTransform:'capitalize'}}>{(status||'').replace(/_/g,' ')}</span>;
}
function StatMini({ label, value }) {
return (
<div className="card text-center">
<div className="text-xl font-bold text-dk-dark">{value}</div>
<div className="text-xs text-gray-500 mt-1">{label}</div>
</div>
);
}