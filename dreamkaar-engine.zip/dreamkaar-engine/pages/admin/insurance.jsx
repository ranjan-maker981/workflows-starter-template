import Layout from '../../components/Layout';
import { useState, useEffect } from 'react';
import DataTable from '../../components/DataTable';
export default function AdminInsurance() {
const [partners, setPartners] = useState([]);
useEffect(() => { fetch('/api/insurance/partners').then(r=>r.json()).then(d=>setPartners(d.partners||[])); }, []);
const columns = [
{ key: 'name', label: 'Partner', render: v => <span className="font-medium">{v}</span> },
{ key: 'comprehensive_rate', label: 'Comp Rate', render: v => `${v}%` },
{ key: 'tp_rate', label: 'TP Rate', render: v => `${v}%` },
{ key: 'zero_dep_addon', label: 'Zero Dep', render: v => `${v}%` },
{ key: 'dk_commission_pct', label: 'DK Comm', render: v => `${v}%` },
{ key: 'status', label: 'Status', render: v => <span className="badge-success">{v}</span> },
];
return (
<Layout title="Insurance Partners">
<DataTable columns={columns} data={partners} emptyMessage="No insurance partners configured" />
</Layout>
);
}