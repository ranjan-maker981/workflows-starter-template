import Layout from '../../components/Layout';
export default function Settings() {
return (
<Layout title="Settings">
<div className="max-w-2xl space-y-6">
<div className="card">
<h3 className="font-semibold mb-4">General Settings</h3>
<div className="space-y-4">
<div><label className="label-field">Business Name</label><input className="input-field" defaultValue="DreamKaar / OneDreamCar" /></div>
<div><label className="label-field">Admin Phone</label><input className="input-field" defaultValue="+917678675011" /></div>
<div><label className="label-field">Default City</label><input className="input-field" defaultValue="Delhi" /></div>
<div><label className="label-field">Token Amount (₹)</label><input className="input-field" type="number" defaultValue="10000" /></div>
</div>
<button className="btn-primary mt-4">Save Settings</button>
</div>
<div className="card">
<h3 className="font-semibold mb-4">Embed Widgets</h3>
<p className="text-sm text-gray-500 mb-4">Copy these iframe codes to embed on dreamkaar.com:</p>
<div className="space-y-3">
<EmbedCode label="Lead Capture Form" path="/embed/lead-form" />
<EmbedCode label="EMI Calculator" path="/embed/emi-calculator" />
<EmbedCode label="Price Checker" path="/embed/price-check" />
</div>
</div>
<div className="card">
<h3 className="font-semibold mb-4">API Endpoints</h3>
<p className="text-sm text-gray-500 mb-3">For developer integration with dreamkaar.com:</p>
<div className="bg-gray-50 p-4 rounded-lg text-xs font-mono space-y-2">
<p>POST /api/leads — Create lead</p>
<p>GET /api/vehicles?search=creta — Search vehicles</p>
<p>POST /api/finance/compare — Compare loan options</p>
<p>POST /api/vehicles/onroad — Calculate on-road price</p>
<p>POST /api/discount/predict — Get discount prediction</p>
</div>
</div>
</div>
</Layout>
);
}
function EmbedCode({ label, path }) {
const url = typeof window !== 'undefined' ? window.location.origin + path : path;
const code = `<iframe src="${url}" width="100%" height="500" frameborder="0"></iframe>`;
return (
<div>
<p className="text-sm font-medium mb-1">{label}</p>
<div className="flex gap-2">
<input className="input-field text-xs font-mono flex-1" readOnly value={code} />
<button onClick={() => navigator.clipboard?.writeText(code)} className="btn-ghost text-xs">Copy</button>
</div>
</div>
);
}