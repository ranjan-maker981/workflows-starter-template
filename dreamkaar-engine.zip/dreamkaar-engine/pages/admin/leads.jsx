import { useState, useEffect } from 'react';
import Layout from '../../components/Layout';
import DataTable from '../../components/DataTable';
import Modal from '../../components/Modal';
const SOURCES = ['website','whatsapp','phone','walk_in','dsa','referral','google_ads','facebook','instagram','justdial','cardekho','carwale','field_capture','other'];
const STATUSES = ['new','assigned','contacted','quoted','negotiating','finance_processing','delivery_pending','delivered','lost'];
const PRIORITIES = ['high','medium','low'];
export default function AdminLeads() {
const [leads, setLeads] = useState([]);
const [loading, setLoading] = useState(true);
const [showAdd, setShowAdd] = useState(false);
const [showDetail, setShowDetail] = useState(null);
const [filters, setFilters] = useState({ status: '', source: '', priority: '' });
const [form, setForm] = useState({
customer_name: '', customer_phone: '', customer_email: '',
customer_city: '', model_interest: '', source: 'website',
priority: 'medium', budget_min: '', budget_max: '', notes: '',
vehicle_category: 'pv', finance_required: false,
});
useEffect(() => { fetchLeads(); }, [filters]);
async function fetchLeads() {
const params = new URLSearchParams();
if (filters.status) params.set('status', filters.status);
if (filters.source) params.set('source', filters.source);
if (filters.priority) params.set('priority', filters.priority);
const res = await fetch(`/api/leads?${params}`);
const data = await res.json();
setLeads(data.leads || []);
setLoading(false);
}
async function createLead() {
const res = await fetch('/api/leads', {
method: 'POST',
headers: { 'Content-Type': 'application/json' },
body: JSON.stringify(form),
});
if (res.ok) {
setShowAdd(false);
setForm({ customer_name: '', customer_phone: '', customer_email: '', customer_city: '',
model_interest: '', source: 'website', priority: 'medium', budget_min: '', budget_max: '',
notes: '', vehicle_category: 'pv', finance_required: false });
fetchLeads();
}
}
async function updateLeadStatus(id, status) {
await fetch(`/api/leads/${id}`, {
method: 'PATCH',
headers: { 'Content-Type': 'application/json' },
body: JSON.stringify({ status }),
});
fetchLeads();
if (showDetail?.id === id) setShowDetail({ ...showDetail, status });
}
const columns = [
{ key: 'customer_name', label: 'Name', render: (v) => <span className="font-medium">{v}</span> },
{ key: 'customer_phone', label: 'Phone' },
{ key: 'model_interest', label: 'Model Interest' },
{ key: 'source', label: 'Source', render: (v) => <span className="badge-info capitalize">{(v || '').replace(/_/g, ' ')}</span> },
{ key: 'status', label: 'Status', render: (v) => <StatusBadge status={v} /> },
{ key: 'priority', label: 'Priority', render: (v) => (
<span className={v === 'high' ? 'badge-danger' : v === 'medium' ? 'badge-warning' : 'badge-neutral'}>
{v}
</span>
)},
{ key: 'score', label: 'Score', render: (v) => <ScoreBadge score={v} /> },
{ key: 'customer_city', label: 'City' },
{ key: 'created_at', label: 'Created', render: (v) => v ? new Date(v).toLocaleDateString('en-IN') : '-' },
];
return (
<Layout title="Leads Management">
{/* Filters */}
<div className="flex flex-wrap gap-3 mb-6">
<select className="select-field w-auto" value={filters.status}
onChange={e => setFilters({ ...filters, status: e.target.value })}>
<option value="">All Statuses</option>
{STATUSES.map(s => <option key={s} value={s}>{s.replace(/_/g, ' ')}</option>)}
</select>
<select className="select-field w-auto" value={filters.source}
onChange={e => setFilters({ ...filters, source: e.target.value })}>
<option value="">All Sources</option>
{SOURCES.map(s => <option key={s} value={s}>{s.replace(/_/g, ' ')}</option>)}
</select>
<select className="select-field w-auto" value={filters.priority}
onChange={e => setFilters({ ...filters, priority: e.target.value })}>
<option value="">All Priorities</option>
{PRIORITIES.map(p => <option key={p} value={p}>{p}</option>)}
</select>
<div className="flex-1" />
<button onClick={() => setShowAdd(true)} className="btn-primary">+ New Lead</button>
</div>
<DataTable columns={columns} data={leads} onRowClick={setShowDetail}
emptyMessage="No leads found. Create your first lead!" />
{/* Add Lead Modal */}
<Modal isOpen={showAdd} onClose={() => setShowAdd(false)} title="New Lead" size="lg">
<div className="grid md:grid-cols-2 gap-4">
<div>
<label className="label-field">Customer Name *</label>
<input className="input-field" value={form.customer_name}
onChange={e => setForm({ ...form, customer_name: e.target.value })} />
</div>
<div>
<label className="label-field">Phone *</label>
<input className="input-field" value={form.customer_phone}
onChange={e => setForm({ ...form, customer_phone: e.target.value })} />
</div>
<div>
<label className="label-field">Email</label>
<input className="input-field" type="email" value={form.customer_email}
onChange={e => setForm({ ...form, customer_email: e.target.value })} />
</div>
<div>
<label className="label-field">City</label>
<input className="input-field" value={form.customer_city}
onChange={e => setForm({ ...form, customer_city: e.target.value })} />
</div>
<div>
<label className="label-field">Model Interest</label>
<input className="input-field" placeholder="e.g. Hyundai Creta" value={form.model_interest}
onChange={e => setForm({ ...form, model_interest: e.target.value })} />
</div>
<div>
<label className="label-field">Category</label>
<select className="select-field" value={form.vehicle_category}
onChange={e => setForm({ ...form, vehicle_category: e.target.value })}>
<option value="pv">Passenger Vehicle</option>
<option value="cv">Commercial Vehicle</option>
<option value="3w">Three Wheeler</option>
</select>
</div>
<div>
<label className="label-field">Source</label>
<select className="select-field" value={form.source}
onChange={e => setForm({ ...form, source: e.target.value })}>
{SOURCES.map(s => <option key={s} value={s}>{s.replace(/_/g, ' ')}</option>)}
</select>
</div>
<div>
<label className="label-field">Priority</label>
<select className="select-field" value={form.priority}
onChange={e => setForm({ ...form, priority: e.target.value })}>
{PRIORITIES.map(p => <option key={p} value={p}>{p}</option>)}
</select>
</div>
<div>
<label className="label-field">Budget Min (₹)</label>
<input className="input-field" type="number" value={form.budget_min}
onChange={e => setForm({ ...form, budget_min: e.target.value })} />
</div>
<div>
<label className="label-field">Budget Max (₹)</label>
<input className="input-field" type="number" value={form.budget_max}
onChange={e => setForm({ ...form, budget_max: e.target.value })} />
</div>
<div className="md:col-span-2">
<label className="label-field">Notes</label>
<textarea className="input-field" rows={3} value={form.notes}
onChange={e => setForm({ ...form, notes: e.target.value })} />
</div>
<div className="md:col-span-2 flex items-center gap-2">
<input type="checkbox" checked={form.finance_required}
onChange={e => setForm({ ...form, finance_required: e.target.checked })} />
<label className="text-sm">Finance Required</label>
</div>
</div>
<div className="flex justify-end gap-3 mt-6">
<button onClick={() => setShowAdd(false)} className="btn-ghost">Cancel</button>
<button onClick={createLead} className="btn-primary"
disabled={!form.customer_name || !form.customer_phone}>Create Lead</button>
</div>
</Modal>
{/* Lead Detail Modal */}
<Modal isOpen={!!showDetail} onClose={() => setShowDetail(null)} title="Lead Details" size="lg">
{showDetail && (
<div>
<div className="grid md:grid-cols-2 gap-4 mb-6">
<div><span className="text-sm text-gray-500">Name</span><p className="font-medium">{showDetail.customer_name}</p></div>
<div><span className="text-sm text-gray-500">Phone</span><p>{showDetail.customer_phone}</p></div>
<div><span className="text-sm text-gray-500">City</span><p>{showDetail.customer_city || '-'}</p></div>
<div><span className="text-sm text-gray-500">Model</span><p>{showDetail.model_interest || '-'}</p></div>
<div><span className="text-sm text-gray-500">Source</span><p className="capitalize">{(showDetail.source || '').replace(/_/g, ' ')}</p></div>
<div><span className="text-sm text-gray-500">Score</span><p>{showDetail.score}</p></div>
<div>
<span className="text-sm text-gray-500">Budget</span>
<p>₹{(showDetail.budget_min || 0).toLocaleString('en-IN')} - ₹{(showDetail.budget_max || 0).toLocaleString('en-IN')}</p>
</div>
<div><span className="text-sm text-gray-500">Finance</span><p>{showDetail.finance_required ? 'Yes' : 'No'}</p></div>
</div>
<div className="mb-4">
<label className="label-field">Update Status</label>
<div className="flex flex-wrap gap-2">
{STATUSES.map(s => (
<button key={s} onClick={() => updateLeadStatus(showDetail.id, s)}
className={`px-3 py-1.5 rounded-lg text-xs font-medium capitalize transition-colors
${showDetail.status === s ? 'bg-dk-primary text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}>
{s.replace(/_/g, ' ')}
</button>
))}
</div>
</div>
{showDetail.notes && (
<div className="mt-4">
<span className="text-sm text-gray-500">Notes</span>
<p className="mt-1 text-sm bg-gray-50 p-3 rounded-lg">{showDetail.notes}</p>
</div>
)}
</div>
)}
</Modal>
</Layout>
);
}
function StatusBadge({ status }) {
const colors = {
new: 'badge-info', assigned: 'badge-neutral', contacted: 'badge-info',
quoted: 'badge-warning', negotiating: 'badge-warning',
finance_processing: 'badge-info', delivery_pending: 'badge-success',
delivered: 'badge-success', lost: 'badge-danger',
};
return <span className={colors[status] || 'badge-neutral'} style={{textTransform:'capitalize'}}>{(status || '').replace(/_/g, ' ')}</span>;
}
function ScoreBadge({ score }) {
const color = score >= 80 ? 'badge-success' : score >= 50 ? 'badge-warning' : 'badge-danger';
return <span className={color}>{score}</span>;
}