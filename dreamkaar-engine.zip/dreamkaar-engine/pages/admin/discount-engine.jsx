import { useState, useEffect } from 'react';
import Layout from '../../components/Layout';
export default function DiscountEngine() {
const [models, setModels] = useState([]);
const [selected, setSelected] = useState(null);
const [city, setCity] = useState('Delhi');
const [prediction, setPrediction] = useState(null);
const [onroad, setOnroad] = useState(null);
const [search, setSearch] = useState('');
useEffect(() => { fetchModels(); }, []);
async function fetchModels() {
const res = await fetch('/api/vehicles?limit=500');
const data = await res.json();
setModels(data.models || []);
}
async function predict() {
if (!selected) return;
const now = new Date();
const res = await fetch('/api/discount/predict', {
method: 'POST',
headers: { 'Content-Type': 'application/json' },
body: JSON.stringify({ model_id: selected.id, city, month: now.getMonth() + 1, year: now.getFullYear() }),
});
const data = await res.json();
setPrediction(data);
// Also get on-road price
const orRes = await fetch('/api/vehicles/onroad', {
method: 'POST',
headers: { 'Content-Type': 'application/json' },
body: JSON.stringify({ ex_showroom: selected.ex_showroom_min, state: cityToState(city), discount: data.predicted || 0 }),
});
const orData = await orRes.json();
setOnroad(orData);
}
const filtered = models.filter(m =>
m.name.toLowerCase().includes(search.toLowerCase()) ||
(m.brand_name || '').toLowerCase().includes(search.toLowerCase())
);
return (
<Layout title="AI Discount Engine">
<div className="grid md:grid-cols-3 gap-6">
{/* Model Selector */}
<div className="card">
<h3 className="text-sm font-semibold text-gray-600 mb-3">Select Model</h3>
<input className="input-field mb-3" placeholder="Search models..."
value={search} onChange={e => setSearch(e.target.value)} />
<div className="max-h-96 overflow-y-auto space-y-1">
{filtered.slice(0, 50).map(m => (
<button key={m.id} onClick={() => { setSelected(m); setPrediction(null); setOnroad(null); }}
className={`w-full text-left px-3 py-2 rounded-lg text-sm transition-colors
${selected?.id === m.id ? 'bg-dk-primary/10 text-dk-primary' : 'hover:bg-gray-50'}`}>
<div className="font-medium">{m.name}</div>
<div className="text-xs text-gray-400">₹{(m.ex_showroom_min || 0).toLocaleString('en-IN')} - ₹{(m.ex_showroom_max || 0).toLocaleString('en-IN')}</div>
</button>
))}
</div>
</div>
{/* Prediction */}
<div className="md:col-span-2 space-y-4">
{selected && (
<div className="card">
<h3 className="text-lg font-semibold mb-4">{selected.name}</h3>
<div className="flex gap-4 mb-4">
<div>
<label className="label-field">City</label>
<input className="input-field" value={city} onChange={e => setCity(e.target.value)} />
</div>
<div className="flex items-end">
<button onClick={predict} className="btn-primary">Predict Discount</button>
</div>
</div>
<div className="grid grid-cols-2 gap-3 text-sm">
<div className="bg-gray-50 p-3 rounded-lg">
<span className="text-gray-500">Ex-Showroom Range</span>
<p className="font-semibold">₹{(selected.ex_showroom_min || 0).toLocaleString('en-IN')} - ₹{(selected.ex_showroom_max || 0).toLocaleString('en-IN')}</p>
</div>
<div className="bg-gray-50 p-3 rounded-lg">
<span className="text-gray-500">Segment</span>
<p className="font-semibold">{selected.segment}</p>
</div>
<div className="bg-gray-50 p-3 rounded-lg">
<span className="text-gray-500">Fuel Options</span>
<p className="font-semibold">{selected.fuel_types}</p>
</div>
<div className="bg-gray-50 p-3 rounded-lg">
<span className="text-gray-500">Avg Monthly Sales</span>
<p className="font-semibold">{(selected.avg_monthly_sales || 0).toLocaleString('en-IN')}</p>
</div>
</div>
</div>
)}
{prediction && (
<div className="card border-2 border-dk-primary/20">
<h3 className="text-sm font-semibold text-dk-primary mb-4">Discount Prediction</h3>
<div className="grid grid-cols-3 gap-4 mb-4">
<div className="text-center p-4 bg-green-50 rounded-xl">
<div className="text-xs text-gray-500">Min Discount</div>
<div className="text-xl font-bold text-green-700">₹{(prediction.min || 0).toLocaleString('en-IN')}</div>
</div>
<div className="text-center p-4 bg-dk-primary/5 rounded-xl border-2 border-dk-primary/20">
<div className="text-xs text-gray-500">Predicted</div>
<div className="text-2xl font-bold text-dk-primary">₹{(prediction.predicted || 0).toLocaleString('en-IN')}</div>
</div>
<div className="text-center p-4 bg-blue-50 rounded-xl">
<div className="text-xs text-gray-500">Max Discount</div>
<div className="text-xl font-bold text-blue-700">₹{(prediction.max || 0).toLocaleString('en-IN')}</div>
</div>
</div>
<div className="flex items-center gap-2 mb-4">
<span className="text-sm text-gray-500">Confidence:</span>
<span className={`badge ${
prediction.confidence === 'high' ? 'badge-success' :
prediction.confidence === 'medium' ? 'badge-warning' : 'badge-danger'
}`}>{prediction.confidence}</span>
<span className="text-sm text-gray-500 ml-4">Source:</span>
<span className="badge-neutral">{prediction.source}</span>
</div>
{prediction.margin && (
<div className="border-t pt-4 mt-4">
<h4 className="text-sm font-semibold text-gray-600 mb-3">Margin Breakdown</h4>
<div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
<div className="bg-gray-50 p-2 rounded-lg">
<span className="text-gray-400 text-xs">OEM Margin</span>
<p className="font-medium">{prediction.margin.oem_pct}%</p>
</div>
<div className="bg-gray-50 p-2 rounded-lg">
<span className="text-gray-400 text-xs">Dealer Margin</span>
<p className="font-medium">{prediction.margin.dealer_pct}%</p>
</div>
<div className="bg-gray-50 p-2 rounded-lg">
<span className="text-gray-400 text-xs">Incentive/unit</span>
<p className="font-medium">₹{(prediction.margin.incentive || 0).toLocaleString('en-IN')}</p>
</div>
<div className="bg-gray-50 p-2 rounded-lg">
<span className="text-gray-400 text-xs">Holdback</span>
<p className="font-medium">{prediction.margin.holdback_pct}%</p>
</div>
</div>
</div>
)}
</div>
)}
{onroad && (
<div className="card">
<h3 className="text-sm font-semibold text-gray-600 mb-4">On-Road Price Breakdown</h3>
<div className="space-y-2">
{(onroad.breakdown || []).map((item, i) => (
<div key={i} className={`flex justify-between py-2 ${item.isTotal ? 'border-t-2 border-dk-dark pt-3 mt-2 font-bold text-lg' : 'text-sm'}`}>
<span className={item.amount < 0 ? 'text-green-600' : ''}>{item.label}</span>
<span className={item.amount < 0 ? 'text-green-600' : ''}>
{item.amount < 0 ? '-' : ''}₹{Math.abs(item.amount).toLocaleString('en-IN')}
</span>
</div>
))}
</div>
</div>
)}
</div>
</div>
</Layout>
);
}
function cityToState(city) {
const map = {
'Delhi': 'Delhi', 'Mumbai': 'Maharashtra', 'Pune': 'Maharashtra', 'Bangalore': 'Karnataka',
'Chennai': 'Tamil Nadu', 'Hyderabad': 'Telangana', 'Kolkata': 'West Bengal', 'Jaipur': 'Rajasthan',
'Ahmedabad': 'Gujarat', 'Lucknow': 'Uttar Pradesh', 'Chandigarh': 'Chandigarh',
};
return map[city] || 'Delhi';
}