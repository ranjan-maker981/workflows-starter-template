import { useState, useEffect } from 'react';
import Layout from '../../components/Layout';
import { BarChartWidget, PieChartWidget, LineChartWidget, AreaChartWidget } from '../../components/Charts';
export default function Analytics() {
const [data, setData] = useState({});
useEffect(() => { fetch('/api/analytics/dashboard').then(r=>r.json()).then(setData); }, []);
return (
<Layout title="Analytics">
<div className="grid md:grid-cols-2 gap-6 mb-6">
<BarChartWidget title="Leads by Source" data={data.leadsBySource||[]} xKey="source" yKey="count" />
<PieChartWidget title="Lead Status Distribution" data={data.leadsByStatus||[]} nameKey="status" valueKey="count" />
</div>
<div className="grid md:grid-cols-2 gap-6 mb-6">
<LineChartWidget title="Leads Trend (30 Days)" data={data.leadsTrend||[]} xKey="date" lines={[{key:'leads',label:'New'},{key:'converted',label:'Converted'}]} />
<BarChartWidget title="Top Models" data={(data.topModels||[]).slice(0,10)} xKey="model" yKey="count" color="#1D3557" />
</div>
<div className="grid md:grid-cols-2 gap-6">
<div className="card">
<h3 className="text-sm font-semibold text-gray-600 mb-4">Channel Attribution</h3>
<p className="text-gray-400 text-center py-8">Revenue attribution per channel will populate as deals are completed</p>
</div>
<div className="card">
<h3 className="text-sm font-semibold text-gray-600 mb-4">Customer LTV Cohorts</h3>
<p className="text-gray-400 text-center py-8">Cohort analysis will populate with 3+ months of data</p>
</div>
</div>
</Layout>
);
}