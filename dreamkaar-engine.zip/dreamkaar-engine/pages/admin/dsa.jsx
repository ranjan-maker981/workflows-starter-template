import { useState, useEffect } from 'react';
import Layout from '../../components/Layout';
import DataTable from '../../components/DataTable';
export default function AdminDSA() {
const [dsas, setDsas] = useState([]);
useEffect(() => { fetch('/api/dsa').then(r=>r.json()).then(d=>setDsas(d.dsas||[])); }, []);
async function updateStatus(id, status) {
await fetch(`/api/dsa/${id}`, { method:'PATCH', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ status }) });
setDsas(prev => prev.map(d => d.id === id ? { ...d, status } : d));
}
const columns = [
{ key: 'name', label: 'Name', render: v => <span className="font-medium">{v}</span> },
{ key: 'phone', label: 'Phone' },
{ key: 'city', label: 'City' },
{ key: 'specialization', label: 'Type', render: v => <span className="badge-info uppercase">{v}</span> },
{ key: 'total_leads', label: 'Leads' },
{ key: 'total_conversions', label: 'Conversions' },
{ key: 'total_earned', label: 'Earned', render: v => `₹${(v||0).toLocaleString('en-IN')}` },
{ key: 'status', label: 'Status', render: (v, row) => (
<select className="select-field text-xs py-1 w-auto" value={v} onChange={e => updateStatus(row.id, e.target.value)}>
<option value="pending">Pending</option><option value="approved">Approved</option><option value="rejected">Rejected</option><option value="suspended">Suspended</option>
</select>
)},
];
return (
<Layout title="DSA Network">
<div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
<MiniStat label="Total DSAs" value={dsas.length} />
<MiniStat label="Approved" value={dsas.filter(d=>d.status==='approved').length} />
<MiniStat label="Pending" value={dsas.filter(d=>d.status==='pending').length} />
<MiniStat label="Total Conversions" value={dsas.reduce((s,d)=>s+(d.total_conversions||0),0)} />
</div>
<DataTable columns={columns} data={dsas} emptyMessage="No DSAs registered yet" />
</Layout>
);
}
function MiniStat({ label, value }) {
return <div className="card text-center"><div className="text-xl font-bold">{value}</div><div className="text-xs text-gray-500 mt-1">{label}</div></div>;
}