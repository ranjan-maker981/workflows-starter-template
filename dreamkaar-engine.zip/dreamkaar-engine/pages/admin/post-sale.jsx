import Layout from '../../components/Layout';
export default function PostSale() {
return <Layout title="Post-Sale Lifecycle"><div className="card"><p className="text-gray-400 text-center py-12">Insurance renewals, service reminders, and upsell prompts will appear here as deals age. System auto-generates reminders at 6-month, 11-month, 2-year, and 3-year marks.</p></div></Layout>;
}