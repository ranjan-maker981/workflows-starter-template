import { useState, useEffect } from 'react';
import Layout from '../../components/Layout';
import DataTable from '../../components/DataTable';
export default function AdminUsers() {
const [users, setUsers] = useState([]);
useEffect(() => { fetch('/api/users').then(r=>r.json()).then(d=>setUsers(d.users||[])); }, []);
async function updateRole(id, role) {
await fetch(`/api/users/${id}`, { method:'PATCH', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ role }) });
setUsers(prev => prev.map(u => u.id === id ? { ...u, role } : u));
}
const columns = [
{ key: 'name', label: 'Name', render: v => <span className="font-medium">{v}</span> },
{ key: 'phone', label: 'Phone' },
{ key: 'email', label: 'Email' },
{ key: 'role', label: 'Role', render: (v, row) => (
<select className="select-field text-xs py-1 w-auto" value={v} onChange={e=>updateRole(row.id, e.target.value)}>
{['admin','sales','dsa','dealer','nbfc','fleet','customer'].map(r => <option key={r} value={r}>{r}</option>)}
</select>
)},
{ key: 'city', label: 'City' },
{ key: 'status', label: 'Status', render: v => <span className={v==='active'?'badge-success':'badge-danger'}>{v}</span> },
{ key: 'created_at', label: 'Joined', render: v => v ? new Date(v).toLocaleDateString('en-IN') : '-' },
];
return (
<Layout title="User Management">
<DataTable columns={columns} data={users} />
</Layout>
);
}