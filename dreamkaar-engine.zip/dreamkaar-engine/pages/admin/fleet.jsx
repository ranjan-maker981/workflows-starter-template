import { useState, useEffect } from 'react';
import Layout from '../../components/Layout';
import DataTable from '../../components/DataTable';
export default function AdminFleet() {
const [inquiries, setInquiries] = useState([]);
useEffect(() => { fetch('/api/fleet/inquiries').then(r=>r.json()).then(d=>setInquiries(d.inquiries||[])); }, []);
const columns = [
{ key:'company_name', label:'Company', render:v=><span className="font-medium">{v}</span> },
{ key:'contact_person', label:'Contact' }, { key:'phone', label:'Phone' },
{ key:'vehicle_types', label:'Vehicles' }, { key:'quantity', label:'Qty' },
{ key:'city', label:'City' }, { key:'status', label:'Status', render:v=><span className="badge-info capitalize">{v}</span> },
];
return <Layout title="Fleet Inquiries"><DataTable columns={columns} data={inquiries} emptyMessage="No fleet inquiries" /></Layout>;
}