import { useState, useEffect } from 'react';
import Layout from '../../components/Layout';
const STAGES = [
{ key: 'new', label: 'New', color: '#3B82F6' },
{ key: 'assigned', label: 'Assigned', color: '#6B7280' },
{ key: 'contacted', label: 'Contacted', color: '#8B5CF6' },
{ key: 'quoted', label: 'Quoted', color: '#F59E0B' },
{ key: 'negotiating', label: 'Negotiating', color: '#F97316' },
{ key: 'finance_processing', label: 'Finance', color: '#06B6D4' },
{ key: 'delivery_pending', label: 'Delivery', color: '#10B981' },
{ key: 'delivered', label: 'Delivered', color: '#059669' },
{ key: 'lost', label: 'Lost', color: '#EF4444' },
];
export default function Pipeline() {
const [leads, setLeads] = useState([]);
const [loading, setLoading] = useState(true);
const [draggedLead, setDraggedLead] = useState(null);
useEffect(() => { fetchLeads(); }, []);
async function fetchLeads() {
const res = await fetch('/api/leads?limit=200');
const data = await res.json();
setLeads(data.leads || []);
setLoading(false);
}
async function moveLead(leadId, newStatus) {
await fetch(`/api/leads/${leadId}`, {
method: 'PATCH',
headers: { 'Content-Type': 'application/json' },
body: JSON.stringify({ status: newStatus }),
});
setLeads(prev => prev.map(l => l.id === leadId ? { ...l, status: newStatus } : l));
}
function handleDragStart(lead) { setDraggedLead(lead); }
function handleDrop(stage) {
if (draggedLead && draggedLead.status !== stage) {
moveLead(draggedLead.id, stage);
}
setDraggedLead(null);
}
if (loading) return <Layout title="Pipeline"><div className="animate-pulse">Loading pipeline...</div></Layout>;
return (
<Layout title="Lead Pipeline">
<div className="overflow-x-auto pb-4">
<div className="flex gap-4 min-w-max">
{STAGES.map(stage => {
const stageLeads = leads.filter(l => l.status === stage.key);
return (
<div key={stage.key} className="w-72 flex-shrink-0"
onDragOver={e => e.preventDefault()}
onDrop={() => handleDrop(stage.key)}>
{/* Column Header */}
<div className="flex items-center gap-2 mb-3 px-1">
<div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: stage.color }} />
<span className="text-sm font-semibold text-gray-700">{stage.label}</span>
<span className="badge-neutral ml-auto">{stageLeads.length}</span>
</div>
{/* Column Body */}
<div className="pipeline-column">
{stageLeads.length === 0 ? (
<div className="text-center text-gray-400 text-xs py-8">No leads</div>
) : (
stageLeads.map(lead => (
<div key={lead.id} className="pipeline-card"
draggable onDragStart={() => handleDragStart(lead)}>
<div className="flex items-center justify-between mb-1">
<span className="text-sm font-medium truncate">{lead.customer_name}</span>
<span className={`text-xs px-1.5 py-0.5 rounded ${
lead.priority === 'high' ? 'bg-red-50 text-red-600' :
lead.priority === 'medium' ? 'bg-amber-50 text-amber-600' : 'bg-gray-50 text-gray-500'
}`}>{lead.priority}</span>
</div>
<p className="text-xs text-gray-500 truncate">{lead.model_interest || 'No model'}</p>
<div className="flex items-center justify-between mt-2">
<span className="text-xs text-gray-400">{lead.customer_city || '-'}</span>
<span className="text-xs text-gray-400 capitalize">{(lead.source || '').replace(/_/g, ' ')}</span>
</div>
{lead.score && (
<div className="mt-2">
<div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
<div className="h-full rounded-full" style={{
width: `${lead.score}%`,
backgroundColor: lead.score >= 80 ? '#10B981' : lead.score >= 50 ? '#F59E0B' : '#EF4444'
}} />
</div>
</div>
)}
</div>
))
)}
</div>
</div>
);
})}
</div>
</div>
</Layout>
);
}