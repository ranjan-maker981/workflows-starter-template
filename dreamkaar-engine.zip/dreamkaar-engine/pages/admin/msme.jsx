import Layout from '../../components/Layout';
export default function MSME() {
return <Layout title="MSME Facilitation"><div className="card"><p className="text-gray-400 text-center py-12">MSME vehicle recommendation engine and lighter documentation flow. Routes to MSME-friendly NBFCs (Shriram, Chola, Sundaram) automatically.</p></div></Layout>;
}