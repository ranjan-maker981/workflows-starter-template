import { useState, useEffect } from 'react';
import Layout from '../../components/Layout';
import DataTable from '../../components/DataTable';
export default function AdminFinance() {
const [nbfcs, setNbfcs] = useState([]);
const [apps, setApps] = useState([]);
useEffect(() => {
fetch('/api/finance/partners').then(r=>r.json()).then(d=>setNbfcs(d.partners||[]));
fetch('/api/finance/applications').then(r=>r.json()).then(d=>setApps(d.applications||[]));
}, []);
const nbfcCols = [
{ key: 'name', label: 'NBFC', render: v => <span className="font-medium">{v}</span> },
{ key: 'interest_rate_min', label: 'Rate Min', render: v => `${v}%` },
{ key: 'interest_rate_max', label: 'Rate Max', render: v => `${v}%` },
{ key: 'min_cibil', label: 'Min CIBIL' },
{ key: 'max_ltv_pct', label: 'Max LTV', render: v => `${v}%` },
{ key: 'accepts_bad_cibil', label: 'Bad CIBIL', render: v => v ? <span className="badge-success">Yes</span> : <span className="badge-neutral">No</span> },
{ key: 'dk_commission_pct', label: 'DK Comm%', render: v => `${v}%` },
];
const appCols = [
{ key: 'customer_name', label: 'Customer' },
{ key: 'nbfc_name', label: 'NBFC' },
{ key: 'vehicle_model', label: 'Vehicle' },
{ key: 'loan_amount', label: 'Loan Amt', render: v => v ? `₹${v.toLocaleString('en-IN')}` : '-' },
{ key: 'cibil_score', label: 'CIBIL' },
{ key: 'status', label: 'Status', render: v => <span className={`badge ${v==='approved'?'badge-success':v==='rejected'?'badge-danger':'badge-warning'}`}>{v}</span> },
];
return (
<Layout title="Finance & NBFC">
<h3 className="text-lg font-semibold mb-4">NBFC Partners</h3>
<div className="mb-8"><DataTable columns={nbfcCols} data={nbfcs} /></div>
<h3 className="text-lg font-semibold mb-4">Loan Applications</h3>
<DataTable columns={appCols} data={apps} emptyMessage="No loan applications yet" />
</Layout>
);
}