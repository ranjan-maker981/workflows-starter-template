import { useState, useEffect } from 'react';
import Layout from '../../components/Layout';
import { StatCard, BarChartWidget, PieChartWidget, LineChartWidget } from '../../components/Charts';
export default function AdminDashboard() {
const [stats, setStats] = useState(null);
const [loading, setLoading] = useState(true);
useEffect(() => { fetchDashboard(); }, []);
async function fetchDashboard() {
try {
const res = await fetch('/api/analytics/dashboard');
const data = await res.json();
setStats(data);
} catch (e) { console.error(e); }
setLoading(false);
}
if (loading) return <Layout title="Dashboard"><div className="animate-pulse">Loading dashboard...</div></Layout>;
const s = stats || {};
return (
<Layout title="Admin Dashboard">
{/* KPI Cards */}
<div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
<StatCard icon="👥" label="Total Leads" value={s.totalLeads || 0} change={12} changeType="up" />
<StatCard icon="🆕" label="New Today" value={s.newToday || 0} />
<StatCard icon="🤝" label="Deals This Month" value={s.dealsThisMonth || 0} change={8} changeType="up" />
<StatCard icon="💰" label="Revenue (₹)" value={formatCurrency(s.revenue || 0)} />
</div>
<div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
<StatCard icon="📞" label="Follow-ups Today" value={s.followUpsToday || 0} />
<StatCard icon="⏰" label="Overdue" value={s.overdue || 0} changeType={s.overdue > 0 ? 'down' : 'up'} />
<StatCard icon="🌐" label="Active DSAs" value={s.activeDSAs || 0} />
<StatCard icon="🏪" label="Active Dealers" value={s.activeDealers || 0} />
</div>
{/* Charts Row */}
<div className="grid md:grid-cols-2 gap-6 mb-6">
<BarChartWidget
title="Leads by Source"
data={s.leadsBySource || []}
xKey="source" yKey="count"
/>
<PieChartWidget
title="Lead Status Distribution"
data={s.leadsByStatus || []}
nameKey="status" valueKey="count"
/>
</div>
<div className="grid md:grid-cols-2 gap-6 mb-6">
<LineChartWidget
title="Leads Trend (Last 30 Days)"
data={s.leadsTrend || []}
xKey="date"
lines={[{ key: 'leads', label: 'New Leads' }, { key: 'converted', label: 'Converted' }]}
/>
<BarChartWidget
title="Top Models (by Inquiries)"
data={(s.topModels || []).slice(0, 10)}
xKey="model" yKey="count" color="#1D3557"
/>
</div>
{/* Recent Leads */}
<div className="card">
<h3 className="text-sm font-semibold text-gray-600 mb-4">Recent Leads</h3>
<div className="overflow-x-auto">
<table className="w-full">
<thead>
<tr className="table-header">
<th className="px-4 py-3">Name</th>
<th className="px-4 py-3">Model</th>
<th className="px-4 py-3">Source</th>
<th className="px-4 py-3">Status</th>
<th className="px-4 py-3">City</th>
<th className="px-4 py-3">Score</th>
</tr>
</thead>
<tbody>
{(s.recentLeads || []).map(lead => (
<tr key={lead.id} className="hover:bg-gray-50">
<td className="table-cell font-medium">{lead.customer_name}</td>
<td className="table-cell">{lead.model_interest}</td>
<td className="table-cell">
<span className="badge-info capitalize">{lead.source}</span>
</td>
<td className="table-cell">
<StatusBadge status={lead.status} />
</td>
<td className="table-cell">{lead.customer_city}</td>
<td className="table-cell">
<ScoreBadge score={lead.score} />
</td>
</tr>
))}
</tbody>
</table>
</div>
</div>
</Layout>
);
}
function StatusBadge({ status }) {
const colors = {
new: 'badge-info', assigned: 'badge-neutral', contacted: 'badge-info',
quoted: 'badge-warning', negotiating: 'badge-warning',
finance_processing: 'badge-info', delivery_pending: 'badge-success',
delivered: 'badge-success', lost: 'badge-danger',
};
return <span className={colors[status] || 'badge-neutral'}>{(status || '').replace(/_/g, ' ')}</span>;
}
function ScoreBadge({ score }) {
const color = score >= 80 ? 'badge-success' : score >= 50 ? 'badge-warning' : 'badge-danger';
return <span className={color}>{score}</span>;
}
function formatCurrency(num) {
if (num >= 10000000) return `${(num / 10000000).toFixed(1)}Cr`;
if (num >= 100000) return `${(num / 100000).toFixed(1)}L`;
if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
return num.toString();
}