import Layout from '../../components/Layout';
export default function Documents() {
return <Layout title="Document Tracker"><div className="card"><p className="text-gray-400 text-center py-12">Document tracking is per-deal. Open any deal to manage its document checklist.</p></div></Layout>;
}