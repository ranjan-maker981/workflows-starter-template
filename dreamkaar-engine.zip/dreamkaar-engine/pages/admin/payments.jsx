import Layout from '../../components/Layout';
export default function Payments() {
return <Layout title="Payments"><div className="card"><p className="text-gray-400 text-center py-12">Payment tracking will show here once Razorpay is connected. Token collections, refunds, and commission payouts will appear automatically.</p></div></Layout>;
}