import Layout from '../../components/Layout';
export default function MarketIntelligence() {
return (
<Layout title="Market Intelligence">
<div className="grid md:grid-cols-3 gap-4 mb-6">
<div className="card text-center py-8"><div className="text-3xl mb-2">📊</div><h3 className="font-semibold">Wholesale Data</h3><p className="text-sm text-gray-400 mt-1">OEM dispatch data by brand/model</p></div>
<div className="card text-center py-8"><div className="text-3xl mb-2">🏪</div><h3 className="font-semibold">Retail Data</h3><p className="text-sm text-gray-400 mt-1">FADA/Vahan registration data</p></div>
<div className="card text-center py-8"><div className="text-3xl mb-2">🗺️</div><h3 className="font-semibold">Demand Heatmap</h3><p className="text-sm text-gray-400 mt-1">Regional demand patterns</p></div>
</div>
<div className="card"><p className="text-gray-400 text-center py-12">Market data will populate as you import wholesale/retail CSV data via Admin → Settings. Upload SIAM dispatch data and FADA registration data monthly.</p></div>
</Layout>
);
}