import Layout from '../../components/Layout';
export default function Reports() {
return <Layout title="Reports"><div className="card"><p className="text-gray-400 text-center py-12">Export reports: Lead summary, Deal pipeline, DSA performance, Dealer scorecard, Finance conversion funnel, Revenue breakdown. CSV export coming.</p></div></Layout>;
}