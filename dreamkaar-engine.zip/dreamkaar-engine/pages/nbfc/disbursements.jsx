import Layout from '../../components/Layout';
export default function Disbursements() {
return <Layout title="Disbursements"><div className="card"><p className="text-gray-400 text-center py-12">Disbursement tracking for approved loans.</p></div></Layout>;
}