import { useState, useEffect } from 'react';
import Layout from '../../components/Layout';
import DataTable from '../../components/DataTable';
export default function NBFCApplications() {
const [apps, setApps] = useState([]);
useEffect(() => { fetch('/api/finance/applications').then(r=>r.json()).then(d=>setApps(d.applications||[])); }, []);
async function updateStatus(id, status) {
await fetch(`/api/finance/${id}`, { method:'PATCH', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ status }) });
setApps(prev => prev.map(a => a.id === id ? { ...a, status } : a));
}
const columns = [
{ key: 'customer_name', label: 'Customer', render: v => <span className="font-medium">{v}</span> },
{ key: 'customer_phone', label: 'Phone' },
{ key: 'vehicle_model', label: 'Vehicle' },
{ key: 'loan_amount', label: 'Loan Amount', render: v => v ? `₹${v.toLocaleString('en-IN')}` : '-' },
{ key: 'cibil_score', label: 'CIBIL' },
{ key: 'tenure_months', label: 'Tenure', render: v => v ? `${v}m` : '-' },
{ key: 'status', label: 'Status', render: (v, row) => (
<select className="select-field text-xs py-1 w-auto" value={v} onChange={e => updateStatus(row.id, e.target.value)}>
<option value="submitted">Submitted</option><option value="under_review">Under Review</option>
<option value="approved">Approved</option><option value="rejected">Rejected</option><option value="disbursed">Disbursed</option>
</select>
)},
];
return (
<Layout title="Loan Applications">
<DataTable columns={columns} data={apps} emptyMessage="No applications" />
</Layout>
);
}