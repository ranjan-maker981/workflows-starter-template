import { useState, useEffect } from 'react';
import Layout from '../../components/Layout';
import { StatCard } from '../../components/Charts';
export default function NBFCDashboard() {
const [stats, setStats] = useState({});
useEffect(() => { fetch('/api/finance/applications').then(r=>r.json()).then(d=>{ setStats({ total: d.applications?.length||0, pending: d.applications?.filter(a=>a.status==='submitted').length||0, approved: d.applications?.filter(a=>a.status==='approved').length||0 }); }); }, []);
return (
<Layout title="NBFC Dashboard">
<div className="grid grid-cols-3 gap-4 mb-6">
<StatCard icon="📋" label="Total Applications" value={stats.total||0} />
<StatCard icon="⏳" label="Pending Review" value={stats.pending||0} />
<StatCard icon="✅" label="Approved" value={stats.approved||0} />
</div>
<div className="card"><p className="text-gray-400 text-center py-8">Application management coming — use Applications page from sidebar</p></div>
</Layout>
);
}