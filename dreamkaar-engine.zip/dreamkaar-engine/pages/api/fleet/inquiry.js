import getDb from '../../../lib/db';
import { v4 as uuid } from 'uuid';
export default function handler(req, res) {
if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
const db = getDb();
const f = req.body;
db.prepare(`INSERT INTO fleet_inquiries (id, company_name, contact_person, phone, email, gst, city, vehicle_types, quantity, budget_per_vehicle, delivery_timeline, notes, status)
VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`)
.run(uuid(), f.company_name, f.contact_person, f.phone, f.email||null, f.gst||null, f.city||null, f.vehicle_types||null, parseInt(f.quantity)||0, parseInt(f.budget_per_vehicle)||0, f.delivery_timeline||null, f.notes||null, 'new');
return res.status(201).json({ success: true });
}