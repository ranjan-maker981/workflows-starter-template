import getDb from '../../../lib/db';
import { requireAuth } from '../../../lib/auth';
function handler(req, res) { return res.json({ inquiries: getDb().prepare('SELECT * FROM fleet_inquiries ORDER BY created_at DESC').all() }); }
export default requireAuth(handler, ['admin']);