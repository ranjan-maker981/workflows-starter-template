import getDb from '../../../lib/db';
import { requireAuth } from '../../../lib/auth';
import { v4 as uuid } from 'uuid';
function handler(req, res) {
const db = getDb();
const dealer = db.prepare('SELECT * FROM dealer_profiles WHERE user_id = ?').get(req.user.id);
if (req.method === 'GET') {
if (req.user.role === 'admin') {
const { dealer_id } = req.query;
const inventory = dealer_id
? db.prepare('SELECT * FROM dealer_inventory WHERE dealer_id = ? ORDER BY updated_at DESC').all(dealer_id)
: db.prepare('SELECT * FROM dealer_inventory ORDER BY updated_at DESC').all();
return res.json({ inventory });
}
if (!dealer) return res.json({ inventory: [] });
const inventory = db.prepare('SELECT * FROM dealer_inventory WHERE dealer_id = ? ORDER BY updated_at DESC').all(dealer.id);
return res.json({ inventory });
}
if (req.method === 'POST') {
if (!dealer && req.user.role !== 'admin') return res.status(403).json({ error: 'Not a dealer' });
const dealerId = req.user.role === 'admin' ? (req.body.dealer_id || dealer?.id) : dealer.id;
const { model_name, variant_name, color, quantity, ex_showroom, current_discount, scheme_details } = req.body;
const id = uuid();
db.prepare(`INSERT INTO dealer_inventory (id, dealer_id, model_name, variant_name, color, quantity, ex_showroom, current_discount, scheme_details, updated_at)
VALUES (?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP)`)
.run(id, dealerId, model_name, variant_name || null, color || null, quantity || 0, parseInt(ex_showroom) || 0, parseInt(current_discount) || 0, scheme_details || null);
return res.status(201).json({ success: true });
}
if (req.method === 'PATCH') {
const { id, quantity, current_discount, scheme_details } = req.body;
const updates = [];
const vals = [];
if (quantity !== undefined) { updates.push('quantity = ?'); vals.push(quantity); }
if (current_discount !== undefined) { updates.push('current_discount = ?'); vals.push(current_discount); }
if (scheme_details !== undefined) { updates.push('scheme_details = ?'); vals.push(scheme_details); }
updates.push('updated_at = CURRENT_TIMESTAMP');
vals.push(id);
db.prepare(`UPDATE dealer_inventory SET ${updates.join(', ')} WHERE id = ?`).run(...vals);
return res.json({ success: true });
}
return res.status(405).json({ error: 'Method not allowed' });
}
export default requireAuth(handler, ['dealer', 'admin']);