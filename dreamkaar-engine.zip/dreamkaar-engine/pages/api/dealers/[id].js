import getDb from '../../../lib/db';
import { requireAuth } from '../../../lib/auth';
function handler(req, res) {
const { id } = req.query;
const db = getDb();
if (req.method === 'PATCH') {
const { status } = req.body;
if (status) db.prepare('UPDATE dealer_profiles SET status = ? WHERE id = ?').run(status, id);
return res.json({ success: true });
}
const dealer = db.prepare('SELECT * FROM dealer_profiles WHERE id = ?').get(id);
return res.json({ dealer });
}
export default requireAuth(handler, ['admin']);