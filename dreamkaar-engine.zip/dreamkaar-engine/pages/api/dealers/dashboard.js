import getDb from '../../../lib/db';
import { requireAuth } from '../../../lib/auth';
function handler(req, res) {
const db = getDb();
const dealer = db.prepare('SELECT * FROM dealer_profiles WHERE user_id = ?').get(req.user.id);
if (!dealer) return res.json({ activeOrders: 0, delivered: 0, stockItems: 0, rating: 0, pendingOrders: [], recentDeliveries: [] });
const activeOrders = db.prepare("SELECT COUNT(*) as c FROM deals WHERE dealer_id = ? AND status NOT IN ('delivered','cancelled')").get(dealer.id).c;
const delivered = db.prepare("SELECT COUNT(*) as c FROM deals WHERE dealer_id = ? AND status = 'delivered'").get(dealer.id).c;
const stockItems = db.prepare("SELECT COALESCE(SUM(quantity),0) as c FROM dealer_inventory WHERE dealer_id = ?").get(dealer.id).c;
const pendingOrders = db.prepare("SELECT * FROM deals WHERE dealer_id = ? AND status NOT IN ('delivered','cancelled') ORDER BY created_at DESC LIMIT 10").all(dealer.id);
const recentDeliveries = db.prepare("SELECT * FROM deals WHERE dealer_id = ? AND status = 'delivered' ORDER BY delivery_date_actual DESC LIMIT 10").all(dealer.id);
return res.json({ activeOrders, delivered, stockItems, rating: dealer.reliability_score, pendingOrders, recentDeliveries });
}
export default requireAuth(handler, ['dealer', 'admin']);