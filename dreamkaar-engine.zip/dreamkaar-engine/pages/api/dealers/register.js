import getDb from '../../../lib/db';
import { v4 as uuid } from 'uuid';
export default function handler(req, res) {
if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
const { name, brand, city, state, address, contact_person, phone, email, gst, models_handled } = req.body;
if (!name || !brand || !city || !phone) return res.status(400).json({ error: 'Required fields missing' });
const db = getDb();
const userId = uuid();
db.prepare('INSERT OR IGNORE INTO users (id, phone, name, email, role, status, city) VALUES (?,?,?,?,?,?,?)')
.run(userId, phone.startsWith('+') ? phone : `+91${phone}`, name, email||null, 'dealer', 'active', city);
const dealerId = uuid();
db.prepare(`INSERT INTO dealer_profiles (id, user_id, name, brand, city, state, address, contact_person, phone, email, gst, models_handled, status)
VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`)
.run(dealerId, userId, name, brand, city, state||null, address||null, contact_person||null, phone, email||null, gst||null, models_handled||null, 'pending');
return res.status(201).json({ success: true });
}