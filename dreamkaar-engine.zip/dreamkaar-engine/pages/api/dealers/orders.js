import getDb from '../../../lib/db';
import { requireAuth } from '../../../lib/auth';
function handler(req, res) {
const db = getDb();
const dealer = db.prepare('SELECT * FROM dealer_profiles WHERE user_id = ?').get(req.user.id);
if (!dealer) return res.json({ orders: [] });
const orders = db.prepare('SELECT * FROM deals WHERE dealer_id = ? ORDER BY created_at DESC').all(dealer.id);
return res.json({ orders });
}
export default requireAuth(handler, ['dealer', 'admin']);