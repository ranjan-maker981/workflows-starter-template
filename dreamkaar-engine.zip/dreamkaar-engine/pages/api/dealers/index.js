import getDb from '../../../lib/db';
import { requireAuth } from '../../../lib/auth';
function handler(req, res) {
const db = getDb();
const dealers = db.prepare('SELECT * FROM dealer_profiles ORDER BY total_orders DESC').all();
return res.json({ dealers });
}
export default requireAuth(handler, ['admin']);