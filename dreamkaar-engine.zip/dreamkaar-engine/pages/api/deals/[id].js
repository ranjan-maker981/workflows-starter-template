import getDb from '../../../lib/db';
import { requireAuth } from '../../../lib/auth';
import { v4 as uuid } from 'uuid';
function handler(req, res) {
const { id } = req.query;
const db = getDb();
if (req.method === 'GET') {
const deal = db.prepare('SELECT * FROM deals WHERE id = ?').get(id);
const timeline = db.prepare('SELECT * FROM deal_timeline WHERE deal_id = ? ORDER BY created_at ASC').all(id);
const docs = db.prepare('SELECT * FROM deal_documents WHERE deal_id = ?').all(id);
return res.json({ deal, timeline, documents: docs });
}
if (req.method === 'PATCH') {
const updates = req.body;
const allowed = ['status','payment_status','token_paid','delivery_date_expected','delivery_date_actual',
'loan_status','insurance_type','insurance_provider','insurance_premium'];
const fields = []; const vals = [];
for (const k of allowed) {
if (updates[k] !== undefined) { fields.push(`${k} = ?`); vals.push(updates[k]); }
}
if (fields.length > 0) {
fields.push('updated_at = CURRENT_TIMESTAMP');
vals.push(id);
db.prepare(`UPDATE deals SET ${fields.join(', ')} WHERE id = ?`).run(...vals);
if (updates.status) {
db.prepare('INSERT INTO deal_timeline (id, deal_id, stage, description, user_id) VALUES (?,?,?,?,?)')
.run(uuid(), id, updates.status, `Status updated to ${updates.status}`, req.user.id);
}
}
return res.json({ success: true });
}
return res.status(405).json({ error: 'Method not allowed' });
}
export default requireAuth(handler, ['admin', 'sales', 'dealer']);