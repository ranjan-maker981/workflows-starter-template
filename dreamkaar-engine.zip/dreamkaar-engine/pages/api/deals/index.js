import getDb from '../../../lib/db';
import { requireAuth } from '../../../lib/auth';
import { v4 as uuid } from 'uuid';
function handler(req, res) {
const db = getDb();
if (req.method === 'GET') {
const deals = db.prepare('SELECT * FROM deals ORDER BY created_at DESC').all();
return res.json({ deals });
}
if (req.method === 'POST') {
const d = req.body;
const id = uuid();
const totalRevenue = (d.dk_commission || 0) + (d.finance_commission || 0) + (d.insurance_commission || 0);
db.prepare(`INSERT INTO deals 
(id, lead_id, customer_name, customer_phone, model_id, variant_id, model_name, variant_name, color,
ex_showroom, road_tax, registration, insurance, tcs, accessories, other_charges, on_road_price,
customer_discount, dk_commission, dsa_commission, finance_commission, insurance_commission, total_revenue,
dealer_id, dealer_name, dsa_id, sales_person_id,
finance_required, nbfc_id, loan_amount, emi_amount, loan_tenure, interest_rate, loan_status,
insurance_type, insurance_provider, insurance_premium,
status, payment_status, token_amount, token_paid, delivery_date_expected, created_at, updated_at)
VALUES (${Array(37).fill('?').join(',')}, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)`)
.run(id, d.lead_id || null, d.customer_name, d.customer_phone,
d.model_id || null, d.variant_id || null, d.model_name, d.variant_name || null, d.color || null,
d.ex_showroom || 0, d.road_tax || 0, d.registration || 0, d.insurance || 0, d.tcs || 0,
d.accessories || 0, d.other_charges || 0, d.on_road_price || 0,
d.customer_discount || 0, d.dk_commission || 0, d.dsa_commission || 0,
d.finance_commission || 0, d.insurance_commission || 0, totalRevenue,
d.dealer_id || null, d.dealer_name || null, d.dsa_id || null, d.sales_person_id || req.user.id,
d.finance_required ? 1 : 0, d.nbfc_id || null, d.loan_amount || null,
d.emi_amount || null, d.loan_tenure || null, d.interest_rate || null, d.loan_status || null,
d.insurance_type || null, d.insurance_provider || null, d.insurance_premium || null,
'booked', 'pending', d.token_amount || 10000, 0, d.delivery_date_expected || null);
// Timeline entry
db.prepare('INSERT INTO deal_timeline (id, deal_id, stage, description, user_id) VALUES (?, ?, ?, ?, ?)')
.run(uuid(), id, 'booked', 'Deal created', req.user.id);
// Update lead status if linked
if (d.lead_id) {
db.prepare("UPDATE leads SET status = 'delivery_pending', updated_at = CURRENT_TIMESTAMP WHERE id = ?").run(d.lead_id);
}
const deal = db.prepare('SELECT * FROM deals WHERE id = ?').get(id);
return res.status(201).json({ deal });
}
return res.status(405).json({ error: 'Method not allowed' });
}
export default requireAuth(handler, ['admin', 'sales']);