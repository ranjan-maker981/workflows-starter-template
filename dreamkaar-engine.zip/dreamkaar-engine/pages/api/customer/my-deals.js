import getDb from '../../../lib/db';
import { requireAuth } from '../../../lib/auth';
function handler(req, res) {
const db = getDb();
const deals = db.prepare('SELECT * FROM deals WHERE customer_phone = ? ORDER BY created_at DESC').all(req.user.phone);
const referral = db.prepare('SELECT * FROM referral_codes WHERE customer_phone = ?').get(req.user.phone);
return res.json({ deals, referral });
}
export default requireAuth(handler, ['customer', 'admin']);