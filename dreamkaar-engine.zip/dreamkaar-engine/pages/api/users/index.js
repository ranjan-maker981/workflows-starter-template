import getDb from '../../../lib/db';
import { requireAuth } from '../../../lib/auth';
function handler(req, res) {
const db = getDb();
const users = db.prepare('SELECT * FROM users ORDER BY created_at DESC').all();
return res.json({ users });
}
export default requireAuth(handler, ['admin']);