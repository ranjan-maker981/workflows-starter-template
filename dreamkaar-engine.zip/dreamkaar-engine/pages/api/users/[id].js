import getDb from '../../../lib/db';
import { requireAuth } from '../../../lib/auth';
function handler(req, res) {
const { id } = req.query;
const db = getDb();
if (req.method === 'PATCH') {
const { role, status, name } = req.body;
if (role) db.prepare('UPDATE users SET role = ? WHERE id = ?').run(role, id);
if (status) db.prepare('UPDATE users SET status = ? WHERE id = ?').run(status, id);
if (name) db.prepare('UPDATE users SET name = ? WHERE id = ?').run(name, id);
return res.json({ success: true });
}
const user = db.prepare('SELECT * FROM users WHERE id = ?').get(id);
return res.json({ user });
}
export default requireAuth(handler, ['admin']);