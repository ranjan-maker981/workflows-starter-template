import getDb from '../../../lib/db';
import { requireAuth } from '../../../lib/auth';
function handler(req, res) {
const db = getDb();
// Total leads
const totalLeads = db.prepare('SELECT COUNT(*) as c FROM leads').get().c;
// New today
const today = new Date().toISOString().split('T')[0];
const newToday = db.prepare("SELECT COUNT(*) as c FROM leads WHERE date(created_at) = ?").get(today).c;
// Deals this month
const monthStart = new Date();
monthStart.setDate(1);
const dealsThisMonth = db.prepare(
"SELECT COUNT(*) as c FROM deals WHERE created_at >= ?"
).get(monthStart.toISOString()).c;
// Revenue
const revenue = db.prepare(
"SELECT COALESCE(SUM(dk_commission + COALESCE(finance_commission,0) + COALESCE(insurance_commission,0)),0) as total FROM deals WHERE status = 'delivered'"
).get().total;
// Follow-ups today
const followUpsToday = db.prepare(
"SELECT COUNT(*) as c FROM leads WHERE date(next_follow_up) = ? AND status NOT IN ('delivered','lost')"
).get(today).c;
// Overdue
const overdue = db.prepare(
"SELECT COUNT(*) as c FROM leads WHERE next_follow_up < ? AND status NOT IN ('delivered','lost')"
).get(new Date().toISOString()).c;
// Active DSAs
const activeDSAs = db.prepare("SELECT COUNT(*) as c FROM dsa_profiles WHERE status = 'approved'").get().c;
// Active Dealers
const activeDealers = db.prepare("SELECT COUNT(*) as c FROM dealer_profiles WHERE status = 'approved'").get().c;
// Leads by source
const leadsBySource = db.prepare(
"SELECT source, COUNT(*) as count FROM leads GROUP BY source ORDER BY count DESC"
).all();
// Leads by status
const leadsByStatus = db.prepare(
"SELECT status, COUNT(*) as count FROM leads GROUP BY status ORDER BY count DESC"
).all();
// Leads trend (last 30 days)
const leadsTrend = [];
for (let i = 29; i >= 0; i--) {
const d = new Date();
d.setDate(d.getDate() - i);
const dateStr = d.toISOString().split('T')[0];
const leads = db.prepare("SELECT COUNT(*) as c FROM leads WHERE date(created_at) = ?").get(dateStr).c;
const converted = db.prepare("SELECT COUNT(*) as c FROM deals WHERE date(created_at) = ?").get(dateStr).c;
leadsTrend.push({ date: dateStr.slice(5), leads, converted });
}
// Top models
const topModels = db.prepare(
"SELECT model_interest as model, COUNT(*) as count FROM leads WHERE model_interest IS NOT NULL GROUP BY model_interest ORDER BY count DESC LIMIT 10"
).all();
// Recent leads
const recentLeads = db.prepare(
"SELECT * FROM leads ORDER BY created_at DESC LIMIT 15"
).all();
return res.json({
totalLeads, newToday, dealsThisMonth, revenue,
followUpsToday, overdue, activeDSAs, activeDealers,
leadsBySource, leadsByStatus, leadsTrend, topModels, recentLeads,
});
}
export default requireAuth(handler, ['admin']);