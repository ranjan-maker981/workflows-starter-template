import getDb from '../../../lib/db';
import { requireAuth } from '../../../lib/auth';
function handler(req, res) {
const db = getDb();
const dsa = db.prepare('SELECT * FROM dsa_profiles WHERE user_id = ?').get(req.user.id);
if (!dsa) return res.json({ commissions: [], summary: {} });
const commissions = db.prepare('SELECT * FROM dsa_commissions WHERE dsa_id = ? ORDER BY created_at DESC').all(dsa.id);
const totalEarned = commissions.reduce((s, c) => s + (c.amount || 0), 0);
const totalPaid = commissions.filter(c => c.status === 'paid').reduce((s, c) => s + (c.amount || 0), 0);
return res.json({
commissions,
summary: { totalEarned, totalPaid, pending: totalEarned - totalPaid, totalDeals: commissions.length }
});
}
export default requireAuth(handler, ['dsa']);