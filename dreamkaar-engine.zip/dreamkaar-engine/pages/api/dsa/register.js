import getDb from '../../../lib/db';
import { v4 as uuid } from 'uuid';
export default function handler(req, res) {
if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
const { name, phone, email, city, state, aadhaar, pan, bank_name, bank_account, bank_ifsc, specialization } = req.body;
if (!name || !phone || !city) return res.status(400).json({ error: 'Name, phone, and city required' });
const db = getDb();
// Check if already exists
const existing = db.prepare('SELECT id FROM dsa_profiles WHERE phone = ?').get(phone);
if (existing) return res.status(400).json({ error: 'Phone already registered as DSA' });
// Create user
const userId = uuid();
db.prepare('INSERT OR IGNORE INTO users (id, phone, name, email, role, status, city) VALUES (?,?,?,?,?,?,?)')
.run(userId, phone.startsWith('+') ? phone : `+91${phone}`, name, email || null, 'dsa', 'active', city);
// Create DSA profile
const dsaId = uuid();
db.prepare(`INSERT INTO dsa_profiles (id, user_id, name, phone, email, city, state, aadhaar, pan, bank_name, bank_account, bank_ifsc, specialization, status)
VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`)
.run(dsaId, userId, name, phone, email || null, city, state || null, aadhaar || null, pan || null, bank_name || null, bank_account || null, bank_ifsc || null, specialization || 'pv', 'pending');
return res.status(201).json({ success: true, dsa_id: dsaId });
}