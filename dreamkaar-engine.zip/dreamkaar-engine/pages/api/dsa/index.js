import getDb from '../../../lib/db';
import { requireAuth } from '../../../lib/auth';
function handler(req, res) {
const db = getDb();
const dsas = db.prepare('SELECT * FROM dsa_profiles ORDER BY total_conversions DESC').all();
return res.json({ dsas });
}
export default requireAuth(handler, ['admin']);