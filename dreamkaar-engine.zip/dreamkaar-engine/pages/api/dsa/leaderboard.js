import getDb from '../../../lib/db';
import { requireAuth } from '../../../lib/auth';
function handler(req, res) {
const db = getDb();
const leaderboard = db.prepare(
"SELECT * FROM dsa_profiles WHERE status = 'approved' ORDER BY total_conversions DESC, total_leads DESC LIMIT 20"
).all();
return res.json({ leaderboard });
}
export default requireAuth(handler, ['dsa', 'admin']);