import getDb from '../../../lib/db';
import { requireAuth } from '../../../lib/auth';
function handler(req, res) {
const db = getDb();
const dsa = db.prepare('SELECT * FROM dsa_profiles WHERE user_id = ?').get(req.user.id);
if (!dsa) return res.json({ totalLeads: 0, conversions: 0, totalEarned: 0, pendingPayout: 0, leadsByStatus: [], recentLeads: [] });
const totalLeads = db.prepare('SELECT COUNT(*) as c FROM leads WHERE dsa_id = ?').get(dsa.id).c;
const conversions = db.prepare("SELECT COUNT(*) as c FROM leads WHERE dsa_id = ? AND status = 'delivered'").get(dsa.id).c;
const totalEarned = dsa.total_earned || 0;
const pendingPayout = (dsa.total_earned || 0) - (dsa.total_paid || 0);
const leadsByStatus = db.prepare(
'SELECT status, COUNT(*) as count FROM leads WHERE dsa_id = ? GROUP BY status'
).all(dsa.id);
const recentLeads = db.prepare(
'SELECT * FROM leads WHERE dsa_id = ? ORDER BY created_at DESC LIMIT 10'
).all(dsa.id);
return res.json({ totalLeads, conversions, totalEarned, pendingPayout, leadsByStatus, recentLeads });
}
export default requireAuth(handler, ['dsa']);