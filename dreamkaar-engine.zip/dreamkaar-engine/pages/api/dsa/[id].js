import getDb from '../../../lib/db';
import { requireAuth } from '../../../lib/auth';
function handler(req, res) {
const { id } = req.query;
const db = getDb();
if (req.method === 'PATCH') {
const { status, commission_rate } = req.body;
if (status) {
db.prepare('UPDATE dsa_profiles SET status = ?, approved_at = CURRENT_TIMESTAMP, approved_by = ? WHERE id = ?')
.run(status, req.user.id, id);
}
if (commission_rate !== undefined) {
db.prepare('UPDATE dsa_profiles SET commission_rate = ? WHERE id = ?').run(commission_rate, id);
}
const dsa = db.prepare('SELECT * FROM dsa_profiles WHERE id = ?').get(id);
return res.json({ dsa });
}
const dsa = db.prepare('SELECT * FROM dsa_profiles WHERE id = ?').get(id);
return res.json({ dsa });
}
export default requireAuth(handler, ['admin']);