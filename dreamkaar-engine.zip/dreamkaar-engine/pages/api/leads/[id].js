import getDb from '../../../lib/db';
import { requireAuth } from '../../../lib/auth';
import { v4 as uuid } from 'uuid';
function handler(req, res) {
const { id } = req.query;
const db = getDb();
if (req.method === 'GET') {
const lead = db.prepare('SELECT * FROM leads WHERE id = ?').get(id);
if (!lead) return res.status(404).json({ error: 'Lead not found' });
const activities = db.prepare('SELECT * FROM lead_activities WHERE lead_id = ? ORDER BY created_at DESC').all(id);
const followUps = db.prepare('SELECT * FROM lead_follow_ups WHERE lead_id = ? ORDER BY scheduled_at DESC').all(id);
return res.json({ lead, activities, followUps });
}
if (req.method === 'PATCH') {
const lead = db.prepare('SELECT * FROM leads WHERE id = ?').get(id);
if (!lead) return res.status(404).json({ error: 'Lead not found' });
const updates = req.body;
const fields = [];
const values = [];
const allowed = ['status', 'sub_status', 'priority', 'score', 'assigned_to',
'customer_name', 'customer_phone', 'customer_email', 'customer_city', 'customer_state',
'model_interest', 'variant_interest', 'budget_min', 'budget_max', 'notes',
'lost_reason', 'lost_detail', 'next_follow_up', 'finance_required', 'cibil_range',
'dealer_id', 'expected_purchase_date'];
for (const key of allowed) {
if (updates[key] !== undefined) {
fields.push(`${key} = ?`);
values.push(updates[key]);
}
}
if (fields.length > 0) {
fields.push('updated_at = CURRENT_TIMESTAMP');
if (updates.status && updates.status !== lead.status) {
db.prepare('INSERT INTO lead_activities (id, lead_id, user_id, activity_type, description) VALUES (?, ?, ?, ?, ?)')
.run(uuid(), id, req.user.id, 'status_change', `Status changed: ${lead.status} → ${updates.status}`);
if (updates.status === 'contacted') {
fields.push('last_contacted_at = CURRENT_TIMESTAMP');
}
}
if (updates.assigned_to && updates.assigned_to !== lead.assigned_to) {
fields.push('assigned_at = CURRENT_TIMESTAMP');
}
values.push(id);
db.prepare(`UPDATE leads SET ${fields.join(', ')} WHERE id = ?`).run(...values);
}
const updated = db.prepare('SELECT * FROM leads WHERE id = ?').get(id);
return res.json({ lead: updated });
}
if (req.method === 'DELETE') {
db.prepare('DELETE FROM lead_activities WHERE lead_id = ?').run(id);
db.prepare('DELETE FROM lead_follow_ups WHERE lead_id = ?').run(id);
db.prepare('DELETE FROM leads WHERE id = ?').run(id);
return res.json({ success: true });
}
return res.status(405).json({ error: 'Method not allowed' });
}
export default requireAuth(handler, ['admin', 'sales']);
I'm going to keep going. The next batch will cover the pipeline board, deals, DSA portal, dealer portal, discount engine, and the embeddable widgets. Sending the next set now — don't worry about doing anything yet, just let the files accumulate and I'll tell you when to start assembling.