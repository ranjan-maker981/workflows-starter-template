import getDb from '../../../lib/db';
import { requireAuth } from '../../../lib/auth';
import { v4 as uuid } from 'uuid';
function handler(req, res) {
const db = getDb();
if (req.method === 'GET') {
const { status, source, priority, assigned_to, dsa_id, limit = 100, offset = 0 } = req.query;
let where = [];
let params = [];
if (status) { where.push('status = ?'); params.push(status); }
if (source) { where.push('source = ?'); params.push(source); }
if (priority) { where.push('priority = ?'); params.push(priority); }
if (assigned_to) { where.push('assigned_to = ?'); params.push(assigned_to); }
if (dsa_id) { where.push('dsa_id = ?'); params.push(dsa_id); }
// Sales users only see their assigned leads
if (req.user.role === 'sales') {
where.push('assigned_to = ?');
params.push(req.user.id);
}
// DSA users only see their leads
if (req.user.role === 'dsa') {
const dsa = db.prepare('SELECT id FROM dsa_profiles WHERE user_id = ?').get(req.user.id);
if (dsa) { where.push('dsa_id = ?'); params.push(dsa.id); }
else return res.json({ leads: [] });
}
const whereClause = where.length > 0 ? `WHERE ${where.join(' AND ')}` : '';
const leads = db.prepare(
`SELECT * FROM leads ${whereClause} ORDER BY created_at DESC LIMIT ? OFFSET ?`
).all(...params, parseInt(limit), parseInt(offset));
const total = db.prepare(`SELECT COUNT(*) as c FROM leads ${whereClause}`).all(...params);
return res.json({ leads, total: total[0]?.c || 0 });
}
if (req.method === 'POST') {
const {
customer_name, customer_phone, customer_email, customer_city, customer_state,
model_interest, variant_interest, source, source_detail, priority,
budget_min, budget_max, vehicle_category, notes, finance_required,
cibil_range, exchange_vehicle, dsa_id, campaign, utm_source, utm_medium, utm_campaign,
gps_lat, gps_lng,
} = req.body;
if (!customer_name || !customer_phone) {
return res.status(400).json({ error: 'Name and phone required' });
}
// Auto-score
let score = 50;
if (budget_max > 2500000) score += 20;
else if (budget_max > 1000000) score += 10;
if (finance_required) score += 5;
if (source === 'referral') score += 15;
if (source === 'website' || source === 'google_ads') score += 10;
if (priority === 'high') score += 10;
score = Math.min(score, 100);
// Auto-detect HNI
const isHNI = budget_max > 2500000 || ['bmw', 'mercedes', 'audi', 'porsche', 'land rover', 'lexus', 'volvo']
.some(b => (model_interest || '').toLowerCase().includes(b));
const id = uuid();
const followUp = new Date();
followUp.setHours(followUp.getHours() + 4); // Default: follow up in 4 hours
db.prepare(`INSERT INTO leads 
(id, customer_name, customer_phone, customer_email, customer_city, customer_state,
model_interest, variant_interest, source, source_detail, priority, score,
budget_min, budget_max, vehicle_category, notes, finance_required,
cibil_range, exchange_vehicle, dsa_id, campaign, utm_source, utm_medium, utm_campaign,
gps_lat, gps_lng, status, next_follow_up, created_at, updated_at)
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'new', ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)`)
.run(id, customer_name, customer_phone, customer_email || null, customer_city || null, customer_state || null,
model_interest || null, variant_interest || null, source || 'website', source_detail || null,
isHNI ? 'high' : (priority || 'medium'), score,
budget_min || null, budget_max || null, vehicle_category || 'pv', notes || null,
finance_required ? 1 : 0, cibil_range || null, exchange_vehicle || null,
dsa_id || null, campaign || null, utm_source || null, utm_medium || null, utm_campaign || null,
gps_lat || null, gps_lng || null, followUp.toISOString());
// Log activity
db.prepare('INSERT INTO lead_activities (id, lead_id, user_id, activity_type, description) VALUES (?, ?, ?, ?, ?)')
.run(uuid(), id, req.user?.id || null, 'created', `Lead created via ${source || 'website'}`);
// Auto-assign (round-robin)
const salesUsers = db.prepare("SELECT id FROM users WHERE role = 'sales' AND status = 'active'").all();
if (salesUsers.length > 0) {
const lastAssigned = db.prepare("SELECT assigned_to FROM leads WHERE assigned_to IS NOT NULL ORDER BY assigned_at DESC LIMIT 1").get();
let nextIdx = 0;
if (lastAssigned) {
const lastIdx = salesUsers.findIndex(u => u.id === lastAssigned.assigned_to);
nextIdx = (lastIdx + 1) % salesUsers.length;
}
db.prepare('UPDATE leads SET assigned_to = ?, assigned_at = CURRENT_TIMESTAMP, status = ? WHERE id = ?')
.run(salesUsers[nextIdx].id, 'assigned', id);
}
const lead = db.prepare('SELECT * FROM leads WHERE id = ?').get(id);
return res.status(201).json({ lead });
}
return res.status(405).json({ error: 'Method not allowed' });
}
export default requireAuth(handler, ['admin', 'sales', 'dsa']);