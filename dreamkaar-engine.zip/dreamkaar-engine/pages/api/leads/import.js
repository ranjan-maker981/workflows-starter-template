import getDb from '../../../lib/db';
import { requireAuth } from '../../../lib/auth';
import { v4 as uuid } from 'uuid';
function handler(req, res) {
if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
const { leads } = req.body; // Array of lead objects
if (!Array.isArray(leads)) return res.status(400).json({ error: 'leads must be array' });
const db = getDb();
const stmt = db.prepare(`INSERT INTO leads (id, customer_name, customer_phone, customer_city, model_interest, source, status, priority, score, vehicle_category, created_at, updated_at)
VALUES (?, ?, ?, ?, ?, ?, 'new', 'medium', 50, 'pv', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)`);
let imported = 0;
for (const l of leads) {
if (l.customer_name && l.customer_phone) {
stmt.run(uuid(), l.customer_name, l.customer_phone, l.customer_city || null, l.model_interest || null, l.source || 'import');
imported++;
}
}
return res.json({ imported, total: leads.length });
}
export default requireAuth(handler, ['admin']);