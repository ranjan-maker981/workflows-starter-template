import getDb from '../../../lib/db';
import { requireAuth } from '../../../lib/auth';
function handler(req, res) {
const db = getDb();
const partners = db.prepare("SELECT * FROM nbfc_partners WHERE status = 'active' ORDER BY interest_rate_min ASC").all();
return res.json({ partners });
}
export default requireAuth(handler, ['admin', 'sales', 'dsa', 'nbfc']);