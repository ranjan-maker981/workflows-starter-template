import getDb from '../../../lib/db';
import { requireAuth } from '../../../lib/auth';
function handler(req, res) {
const { id } = req.query;
const db = getDb();
if (req.method === 'PATCH') {
const { status, sanction_amount, rejection_reason } = req.body;
const updates = ['processed_at = CURRENT_TIMESTAMP'];
const vals = [];
if (status) { updates.push('status = ?'); vals.push(status); }
if (sanction_amount) { updates.push('sanction_amount = ?'); vals.push(sanction_amount); }
if (rejection_reason) { updates.push('rejection_reason = ?'); vals.push(rejection_reason); }
vals.push(id);
db.prepare(`UPDATE loan_applications SET ${updates.join(', ')} WHERE id = ?`).run(...vals);
return res.json({ success: true });
}
const app = db.prepare('SELECT * FROM loan_applications WHERE id = ?').get(id);
return res.json({ application: app });
}
export default requireAuth(handler, ['admin', 'nbfc']);