import getDb from '../../../lib/db';
import { requireAuth } from '../../../lib/auth';
function handler(req, res) {
const db = getDb();
let apps;
if (req.user.role === 'nbfc') {
const nbfc = db.prepare('SELECT id FROM nbfc_partners WHERE user_id = ?').get(req.user.id);
apps = nbfc ? db.prepare('SELECT * FROM loan_applications WHERE nbfc_id = ? ORDER BY created_at DESC').all(nbfc.id) : [];
} else {
apps = db.prepare('SELECT * FROM loan_applications ORDER BY created_at DESC').all();
}
return res.json({ applications: apps });
}
export default requireAuth(handler, ['admin', 'nbfc']);