import getDb from '../../../lib/db';
import { calculateEMI } from '../../../lib/onroad-calculator';
export default function handler(req, res) {
if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
const { vehicle_price, down_payment, cibil_score, tenure_months = 60, income_monthly, employment_type } = req.body;
if (!vehicle_price) return res.status(400).json({ error: 'vehicle_price required' });
const db = getDb();
const loanAmount = vehicle_price - (down_payment || 0);
const ltv = (loanAmount / vehicle_price) * 100;
const cibil = cibil_score || 700;
const partners = db.prepare("SELECT * FROM nbfc_partners WHERE status = 'active'").all();
const results = partners.map(p => {
const eligible = cibil >= (p.accepts_bad_cibil && cibil >= p.bad_cibil_min ? p.bad_cibil_min : p.min_cibil) && ltv <= p.max_ltv_pct && tenure_months <= p.max_tenure_months;
let rate = p.interest_rate_min;
if (cibil < 700) rate += 2;
if (cibil < 650) rate += (p.bad_cibil_rate_addon || 3);
if (cibil >= 750) rate = p.interest_rate_min;
rate = Math.min(rate, p.interest_rate_max);
const emi = calculateEMI(loanAmount, rate, tenure_months);
const totalPayable = emi * tenure_months;
const totalInterest = totalPayable - loanAmount;
const processingFee = Math.round(loanAmount * (p.processing_fee_pct / 100));
return {
nbfc_id: p.id,
nbfc_name: p.name,
short_name: p.short_name,
eligible,
interest_rate: rate,
emi,
total_payable: totalPayable,
total_interest: totalInterest,
processing_fee: processingFee,
ltv: Math.round(ltv),
tenure_months: tenure_months,
loan_amount: loanAmount,
accepts_bad_cibil: !!p.accepts_bad_cibil,
dk_commission: Math.round(loanAmount * (p.dk_commission_pct / 100)) + (p.dk_commission_flat || 0),
};
});
results.sort((a, b) => {
if (a.eligible && !b.eligible) return -1;
if (!a.eligible && b.eligible) return 1;
return a.interest_rate - b.interest_rate;
});
return res.json({ results, loan_amount: loanAmount, cibil_score: cibil, ltv: Math.round(ltv) });
}