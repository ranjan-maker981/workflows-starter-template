import getDb from '../../lib/db';
import { v4 as uuid } from 'uuid';
import { PV_BRANDS, PV_MODELS } from '../../lib/seed-data/pv-models';
import { CV_BRANDS, CV_MODELS } from '../../lib/seed-data/cv-models';
import { NBFC_PARTNERS } from '../../lib/seed-data/nbfc-partners';
import { INSURANCE_PARTNERS } from '../../lib/seed-data/insurance-partners';
import { STATE_TAXES } from '../../lib/seed-data/state-taxes';
export default function handler(req, res) {
try {
const db = getDb();
const counts = {};
// Categories
const categories = [
{ id: 'pv', name: 'Passenger Vehicles', slug: 'passenger-vehicles' },
{ id: 'cv', name: 'Commercial Vehicles', slug: 'commercial-vehicles' },
{ id: '3w', name: 'Three Wheelers', slug: 'three-wheelers' },
];
const catStmt = db.prepare('INSERT OR IGNORE INTO vehicle_categories (id, name, slug) VALUES (?, ?, ?)');
categories.forEach(c => catStmt.run(c.id, c.name, c.slug));
counts.categories = categories.length;
// PV Brands
const brandStmt = db.prepare('INSERT OR IGNORE INTO vehicle_brands (id, name, slug, category_id, country) VALUES (?, ?, ?, ?, ?)');
const brandMap = {};
PV_BRANDS.forEach(b => {
const id = `pv-${b.slug}`;
brandStmt.run(id, b.name, b.slug, 'pv', b.country);
brandMap[b.slug] = id;
});
counts.pv_brands = PV_BRANDS.length;
// CV Brands
CV_BRANDS.forEach(b => {
const id = `cv-${b.slug}`;
brandStmt.run(id, b.name, b.slug, 'cv', b.country);
brandMap[b.slug] = id;
});
counts.cv_brands = CV_BRANDS.length;
// PV Models
const modelStmt = db.prepare(`INSERT OR IGNORE INTO vehicle_models 
(id, brand_id, category_id, name, slug, segment, fuel_types, transmission_types, 
ex_showroom_min, ex_showroom_max, is_active, avg_monthly_sales, popularity_rank) 
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)`);
PV_MODELS.forEach(m => {
const brandId = brandMap[m.brand];
if (!brandId) return;
const id = `pv-${m.brand}-${m.name.toLowerCase().replace(/\s+/g, '-')}`;
const slug = `${m.brand}-${m.name.toLowerCase().replace(/\s+/g, '-')}`;
modelStmt.run(id, brandId, 'pv', m.name, slug, m.segment, m.fuel, m.trans, m.min, m.max, m.sales || 0, m.rank || 99);
});
counts.pv_models = PV_MODELS.length;
// CV Models
CV_MODELS.forEach(m => {
const brandId = brandMap[m.brand];
if (!brandId) return;
const id = `cv-${m.brand}-${m.name.toLowerCase().replace(/\s+/g, '-')}`;
const slug = `${m.brand}-${m.name.toLowerCase().replace(/\s+/g, '-')}`;
const cat = m.segment === '3-Wheeler' ? '3w' : 'cv';
modelStmt.run(id, brandId, cat, m.name, slug, m.segment, m.fuel, m.trans, m.min, m.max, m.sales || 0, 99);
});
counts.cv_models = CV_MODELS.length;
// State Taxes
const taxStmt = db.prepare(`INSERT OR IGNORE INTO state_taxes 
(id, state, road_tax_pct, registration_fee, hypothecation_fee, tcs_pct, ev_discount_pct) 
VALUES (?, ?, ?, ?, ?, ?, ?)`);
STATE_TAXES.forEach(s => {
taxStmt.run(`tax-${s.state.toLowerCase().replace(/\s+/g, '-')}`, s.state, s.road_tax_pct, s.reg, s.hypo, s.tcs, s.ev_disc);
});
counts.states = STATE_TAXES.length;
// NBFC Partners
const nbfcStmt = db.prepare(`INSERT OR IGNORE INTO nbfc_partners 
(id, name, short_name, interest_rate_min, interest_rate_max, min_cibil, max_ltv_pct, 
max_tenure_months, processing_fee_pct, dk_commission_pct, dk_commission_flat,
accepts_bad_cibil, bad_cibil_min, bad_cibil_rate_addon, vehicle_types, status) 
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active')`);
NBFC_PARTNERS.forEach(n => {
const id = `nbfc-${n.short_name.toLowerCase().replace(/\s+/g, '-')}`;
nbfcStmt.run(id, n.name, n.short_name, n.rate_min, n.rate_max, n.min_cibil,
n.max_ltv, n.max_tenure, n.processing_fee, n.dk_commission, n.dk_flat || 0,
n.bad_cibil ? 1 : 0, n.bad_cibil_min || 650, n.bad_cibil_addon || 0, n.vehicles);
});
counts.nbfc = NBFC_PARTNERS.length;
// Insurance Partners
const insStmt = db.prepare(`INSERT OR IGNORE INTO insurance_partners 
(id, name, short_name, comprehensive_rate, tp_rate, zero_dep_addon, dk_commission_pct, status) 
VALUES (?, ?, ?, ?, ?, ?, ?, 'active')`);
INSURANCE_PARTNERS.forEach(i => {
const id = `ins-${i.short_name.toLowerCase().replace(/\s+/g, '-')}`;
insStmt.run(id, i.name, i.short_name, i.comp_rate, i.tp_rate, i.zero_dep, i.dk_commission);
});
counts.insurance = INSURANCE_PARTNERS.length;
// Sample Demo Data
seedDemoData(db);
counts.demo = 'seeded';
return res.json({ success: true, counts });
} catch (e) {
console.error('Seed error:', e);
return res.status(500).json({ error: e.message });
}
}
function seedDemoData(db) {
// Sample Admin User
const adminId = uuid();
db.prepare('INSERT OR IGNORE INTO users (id, phone, name, role, status, city) VALUES (?, ?, ?, ?, ?, ?)')
.run(adminId, process.env.ADMIN_PHONE || '+917678675011', 'DreamKaar Admin', 'admin', 'active', 'Delhi');
// Sample Sales Users
const sales1Id = uuid();
const sales2Id = uuid();
db.prepare('INSERT OR IGNORE INTO users (id, phone, name, role, status, city) VALUES (?, ?, ?, ?, ?, ?)')
.run(sales1Id, '+919876543001', 'Rahul Sharma', 'sales', 'active', 'Delhi');
db.prepare('INSERT OR IGNORE INTO users (id, phone, name, role, status, city) VALUES (?, ?, ?, ?, ?, ?)')
.run(sales2Id, '+919876543002', 'Priya Patel', 'sales', 'active', 'Mumbai');
// Sample DSA
const dsaUserId = uuid();
const dsaId = uuid();
db.prepare('INSERT OR IGNORE INTO users (id, phone, name, role, status, city) VALUES (?, ?, ?, ?, ?, ?)')
.run(dsaUserId, '+919876543010', 'Amit DSA Agent', 'dsa', 'active', 'Delhi');
db.prepare(`INSERT OR IGNORE INTO dsa_profiles 
(id, user_id, name, phone, city, state, specialization, status, commission_rate, total_leads, total_conversions, total_earned) 
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
.run(dsaId, dsaUserId, 'Amit DSA Agent', '+919876543010', 'Delhi', 'Delhi', 'pv', 'approved', 2.5, 45, 12, 84000);
// Sample Dealer
const dealerUserId = uuid();
const dealerId = uuid();
db.prepare('INSERT OR IGNORE INTO users (id, phone, name, role, status, city) VALUES (?, ?, ?, ?, ?, ?)')
.run(dealerUserId, '+919876543020', 'AutoMax Delhi', 'dealer', 'active', 'Delhi');
db.prepare(`INSERT OR IGNORE INTO dealer_profiles 
(id, user_id, name, brand, city, state, contact_person, phone, models_handled, 
avg_discount_pct, avg_delivery_days, reliability_score, status, total_orders, total_delivered) 
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
.run(dealerId, dealerUserId, 'AutoMax Delhi', 'Hyundai', 'Delhi', 'Delhi', 'Suresh Kumar',
'+919876543020', 'Creta,Venue,i20,Verna', 4.5, 5, 4.2, 'approved', 120, 115);
// Sample Leads
const leads = [
{ name: 'Vikram Singh', phone: '+919001001001', city: 'Delhi', model: 'Hyundai Creta', source: 'website', status: 'new', priority: 'high', score: 85, budget_min: 1100000, budget_max: 1800000 },
{ name: 'Anita Desai', phone: '+919001001002', city: 'Mumbai', model: 'Maruti Grand Vitara', source: 'whatsapp', status: 'contacted', priority: 'medium', score: 65, budget_min: 1200000, budget_max: 2000000 },
{ name: 'Rajesh Kumar', phone: '+919001001003', city: 'Delhi', model: 'Tata Nexon', source: 'google_ads', status: 'quoted', priority: 'high', score: 78, budget_min: 800000, budget_max: 1400000 },
{ name: 'Meera Joshi', phone: '+919001001004', city: 'Bangalore', model: 'Kia Seltos', source: 'instagram', status: 'negotiating', priority: 'high', score: 90, budget_min: 1100000, budget_max: 1900000 },
{ name: 'Sunil Yadav', phone: '+919001001005', city: 'Delhi', model: 'Mahindra Thar', source: 'referral', status: 'finance_processing', priority: 'medium', score: 72, budget_min: 1200000, budget_max: 1700000 },
{ name: 'Pooja Mehta', phone: '+919001001006', city: 'Pune', model: 'Honda City', source: 'justdial', status: 'new', priority: 'low', score: 40, budget_min: 1100000, budget_max: 1500000 },
{ name: 'Karan Malhotra', phone: '+919001001007', city: 'Delhi', model: 'BMW X1', source: 'website', status: 'new', priority: 'high', score: 92, budget_min: 4000000, budget_max: 5500000 },
{ name: 'Deepak Verma', phone: '+919001001008', city: 'Jaipur', model: 'Maruti Swift', source: 'phone', status: 'contacted', priority: 'medium', score: 55, budget_min: 600000, budget_max: 900000 },
{ name: 'Sneha Reddy', phone: '+919001001009', city: 'Hyderabad', model: 'Tata Punch', source: 'facebook', status: 'new', priority: 'medium', score: 60, budget_min: 600000, budget_max: 900000 },
{ name: 'Arjun Nair', phone: '+919001001010', city: 'Chennai', model: 'Toyota Innova Hycross', source: 'dsa', status: 'quoted', priority: 'high', score: 82, budget_min: 2000000, budget_max: 3000000 },
{ name: 'Pradeep Gupta', phone: '+919001001011', city: 'Delhi', model: 'Tata Ace Gold', source: 'field_capture', status: 'new', priority: 'medium', score: 50, budget_min: 400000, budget_max: 550000 },
{ name: 'Fleet Corp Ltd', phone: '+919001001012', city: 'Mumbai', model: 'Tata Intra V20', source: 'website', status: 'contacted', priority: 'high', score: 88, budget_min: 5000000, budget_max: 8000000 },
];
const leadStmt = db.prepare(`INSERT INTO leads 
(id, customer_name, customer_phone, customer_city, model_interest, source, status, priority, score, 
budget_min, budget_max, vehicle_category, assigned_to, created_at, next_follow_up) 
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`);
const now = new Date();
leads.forEach((l, i) => {
const created = new Date(now);
created.setDate(created.getDate() - Math.floor(Math.random() * 14));
const followUp = new Date(now);
followUp.setDate(followUp.getDate() + Math.floor(Math.random() * 3));
const category = l.model.includes('Ace') || l.model.includes('Intra') ? 'cv' : 'pv';
const assigned = i % 3 === 0 ? sales1Id : i % 3 === 1 ? sales2Id : null;
leadStmt.run(uuid(), l.name, l.phone, l.city, l.model, l.source, l.status, l.priority,
l.score, l.budget_min, l.budget_max, category, assigned,
created.toISOString(), followUp.toISOString());
});
// Sample Deal
const dealId = uuid();
db.prepare(`INSERT INTO deals 
(id, lead_id, customer_name, customer_phone, model_name, variant_name, color,
ex_showroom, road_tax, registration, insurance, tcs, on_road_price,
customer_discount, dk_commission, dealer_id, dealer_name, sales_person_id,
finance_required, loan_amount, emi_amount, loan_tenure, interest_rate, loan_status,
status, payment_status, token_amount, token_paid, delivery_date_expected, created_at) 
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
.run(dealId, null, 'Completed Customer', '+919001002001', 'Hyundai Creta', 'SX(O) 1.5 Turbo DCT', 'Abyss Black',
1810000, 144800, 3000, 52000, 18100, 2027900,
45000, 22000, dealerId, 'AutoMax Delhi', sales1Id,
1, 1600000, 27800, 60, 9.5, 'disbursed',
'delivered', 'paid', 10000, 1, '2026-02-20', new Date(now.setDate(now.getDate() - 10)).toISOString());
// Referral Code for delivered customer
db.prepare(`INSERT INTO referral_codes (id, customer_phone, customer_name, code, referral_reward, referee_discount, status) 
VALUES (?, ?, ?, ?, ?, ?, ?)`)
.run(uuid(), '+919001002001', 'Completed Customer', 'DREAM-CK2026', 2000, 1000, 'active');
}