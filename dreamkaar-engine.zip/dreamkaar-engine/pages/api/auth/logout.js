import { serialize } from 'cookie';
export default function handler(req, res) {
res.setHeader('Set-Cookie', serialize('dk_token', '', {
httpOnly: true, secure: process.env.NODE_ENV === 'production',
sameSite: 'lax', path: '/', maxAge: 0,
}));
return res.json({ success: true });
}