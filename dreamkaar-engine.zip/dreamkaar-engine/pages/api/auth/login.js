import getDb from '../../../lib/db';
import { generateToken } from '../../../lib/auth';
import { serialize } from 'cookie';
import { v4 as uuid } from 'uuid';
export default function handler(req, res) {
if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
const { phone, role, devMode } = req.body;
if (!devMode) return res.status(400).json({ error: 'Use verify-otp for production login' });
const db = getDb();
let user = db.prepare('SELECT * FROM users WHERE phone = ?').get(phone);
if (!user) {
const id = uuid();
const name = role.charAt(0).toUpperCase() + role.slice(1) + ' User';
db.prepare(
'INSERT INTO users (id, phone, name, role, status) VALUES (?, ?, ?, ?, ?)'
).run(id, phone, name, role, 'active');
user = db.prepare('SELECT * FROM users WHERE id = ?').get(id);
}
const token = generateToken(user);
res.setHeader('Set-Cookie', serialize('dk_token', token, {
httpOnly: true, secure: process.env.NODE_ENV === 'production',
sameSite: 'lax', path: '/', maxAge: 30 * 24 * 60 * 60,
}));
return res.json({ user: { id: user.id, phone: user.phone, name: user.name, role: user.role } });
}