import { getSessionFromRequest } from '../../../lib/auth';
export default function handler(req, res) {
const user = getSessionFromRequest(req);
if (!user) return res.status(401).json({ error: 'Not authenticated' });
return res.json({
user: { id: user.id, phone: user.phone, name: user.name, role: user.role, email: user.email, city: user.city }
});
}