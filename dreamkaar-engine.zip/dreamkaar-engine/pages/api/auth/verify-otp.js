import getDb from '../../../lib/db';
import { generateToken } from '../../../lib/auth';
import { serialize } from 'cookie';
import { v4 as uuid } from 'uuid';
export default async function handler(req, res) {
if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
const { phone } = req.body;
if (!phone) return res.status(400).json({ error: 'Phone required' });
const db = getDb();
let user = db.prepare('SELECT * FROM users WHERE phone = ?').get(phone);
if (!user) {
const id = uuid();
const isAdmin = phone === process.env.ADMIN_PHONE;
const role = isAdmin ? 'admin' : 'customer';
const name = isAdmin ? 'Admin' : 'New User';
db.prepare(
'INSERT INTO users (id, phone, name, role, status) VALUES (?, ?, ?, ?, ?)'
).run(id, phone, name, role, 'active');
user = db.prepare('SELECT * FROM users WHERE id = ?').get(id);
}
if (user.status !== 'active') return res.status(403).json({ error: 'Account disabled' });
const token = generateToken(user);
res.setHeader('Set-Cookie', serialize('dk_token', token, {
httpOnly: true, secure: process.env.NODE_ENV === 'production',
sameSite: 'lax', path: '/', maxAge: 30 * 24 * 60 * 60,
}));
return res.json({ user: { id: user.id, phone: user.phone, name: user.name, role: user.role } });
}