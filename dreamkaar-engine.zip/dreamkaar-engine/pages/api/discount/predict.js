import { requireAuth } from '../../../lib/auth';
import { predictDiscount } from '../../../lib/discount-engine';
function handler(req, res) {
if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
const { model_id, city, month, year } = req.body;
if (!model_id) return res.status(400).json({ error: 'model_id required' });
const now = new Date();
const result = predictDiscount(
model_id,
city || 'Delhi',
month || now.getMonth() + 1,
year || now.getFullYear()
);
if (!result) return res.status(404).json({ error: 'Model not found' });
return res.json(result);
}
export default requireAuth(handler, ['admin', 'sales', 'dsa']);