import getDb from '../../../lib/db';
export default function handler(req, res) {
const db = getDb();
const { category, brand, segment, search, limit = 100, offset = 0 } = req.query;
let where = ['vm.is_active = 1'];
let params = [];
if (category) { where.push('vm.category_id = ?'); params.push(category); }
if (brand) { where.push('vb.slug = ?'); params.push(brand); }
if (segment) { where.push('vm.segment = ?'); params.push(segment); }
if (search) {
where.push('(vm.name LIKE ? OR vb.name LIKE ?)');
params.push(`%${search}%`, `%${search}%`);
}
const whereClause = where.length > 0 ? `WHERE ${where.join(' AND ')}` : '';
const models = db.prepare(`
SELECT vm.*, vb.name as brand_name, vb.slug as brand_slug, vc.name as category_name
FROM vehicle_models vm
JOIN vehicle_brands vb ON vm.brand_id = vb.id
JOIN vehicle_categories vc ON vm.category_id = vc.id
${whereClause}
ORDER BY vm.popularity_rank ASC, vm.avg_monthly_sales DESC
LIMIT ? OFFSET ?
`).all(...params, parseInt(limit), parseInt(offset));
return res.json({ models });
}