import { calculateOnRoad } from '../../../lib/onroad-calculator';
export default function handler(req, res) {
if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
const { ex_showroom, state, discount, insurance, accessories, isEV, isFinanced } = req.body;
if (!ex_showroom) return res.status(400).json({ error: 'ex_showroom required' });
const result = calculateOnRoad(ex_showroom, state || 'Delhi', {
discount: discount || 0,
insurance: insurance || 0,
accessories: accessories || 0,
isEV: isEV || false,
isFinanced: isFinanced || false,
});
return res.json(result);
}