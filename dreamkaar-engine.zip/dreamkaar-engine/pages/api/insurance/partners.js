import getDb from '../../../lib/db';
export default function handler(req, res) {
const db = getDb();
const partners = db.prepare("SELECT * FROM insurance_partners WHERE status = 'active'").all();
return res.json({ partners });
}