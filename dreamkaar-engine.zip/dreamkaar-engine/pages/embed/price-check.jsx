import { useState } from 'react';
export default function EmbedPriceCheck() {
const [search, setSearch] = useState('');
const [models, setModels] = useState([]);
const [selected, setSelected] = useState(null);
async function doSearch(q) {
setSearch(q);
if (q.length < 2) { setModels([]); return; }
const res = await fetch(`/api/vehicles?search=${encodeURIComponent(q)}&limit=10`);
const data = await res.json();
setModels(data.models || []);
}
return (
<div style={{ fontFamily:'Inter,sans-serif', padding:20, maxWidth:400 }}>
<h3 style={{ fontSize:18, fontWeight:700, marginBottom:16, color:'#E63946' }}>Check Car Price</h3>
<input placeholder="Search car model..." style={{ width:'100%', padding:'10px 12px', border:'1px solid #ddd', borderRadius:8, fontSize:14, boxSizing:'border-box', marginBottom:8 }}
value={search} onChange={e => doSearch(e.target.value)} />
{models.length > 0 && !selected && (
<div style={{ border:'1px solid #eee', borderRadius:8, maxHeight:200, overflow:'auto' }}>
{models.map(m => (
<div key={m.id} onClick={() => { setSelected(m); setModels([]); }} style={{ padding:'10px 12px', cursor:'pointer', borderBottom:'1px solid #f5f5f5' }}>
<div style={{ fontWeight:600, fontSize:14 }}>{m.brand_name} {m.name}</div>
<div style={{ fontSize:12, color:'#999' }}>{m.segment} • ₹{(m.ex_showroom_min||0).toLocaleString('en-IN')} onwards</div>
</div>
))}
</div>
)}
{selected && (
<div style={{ backgroundColor:'#f8f8f8', padding:16, borderRadius:12, marginTop:8 }}>
<h4 style={{ fontWeight:700, fontSize:16 }}>{selected.brand_name} {selected.name}</h4>
<p style={{ fontSize:13, color:'#666', marginTop:4 }}>{selected.segment} • {selected.fuel_types}</p>
<div style={{ marginTop:12 }}>
<p style={{ fontSize:12, color:'#999' }}>Ex-Showroom Price Range</p>
<p style={{ fontSize:20, fontWeight:800, color:'#1D3557' }}>₹{(selected.ex_showroom_min||0).toLocaleString('en-IN')} - ₹{(selected.ex_showroom_max||0).toLocaleString('en-IN')}</p>
</div>
<div style={{ marginTop:8, padding:8, backgroundColor:'#ECFDF5', borderRadius:8 }}>
<p style={{ fontSize:12, color:'#059669', fontWeight:600 }}>DreamKaar Discount: Up to ₹{Math.round((selected.ex_showroom_max||0)*0.06).toLocaleString('en-IN')}</p>
</div>
<button onClick={() => { setSelected(null); setSearch(''); }} style={{ marginTop:12, fontSize:13, color:'#E63946', background:'none', border:'none', cursor:'pointer' }}>← Search another car</button>
</div>
)}
<p style={{ fontSize:11, color:'#999', marginTop:12, textAlign:'center' }}>Powered by DreamKaar</p>
</div>
);
}