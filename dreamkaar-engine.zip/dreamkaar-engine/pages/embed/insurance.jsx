export default function EmbedInsurance() {
return (
<div style={{ fontFamily:'Inter,sans-serif', padding:20, maxWidth:400 }}>
<h3 style={{ fontSize:18, fontWeight:700, marginBottom:16, color:'#E63946' }}>Insurance Comparison</h3>
<p style={{ color:'#666', fontSize:14 }}>Compare motor insurance from 10+ partners. Coming soon.</p>
<p style={{ fontSize:11, color:'#999', marginTop:12, textAlign:'center' }}>Powered by DreamKaar</p>
</div>
);
}