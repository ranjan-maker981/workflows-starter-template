import { useState } from 'react';
export default function EmbedEMI() {
const [price, setPrice] = useState(1000000);
const [down, setDown] = useState(200000);
const [rate, setRate] = useState(9.5);
const [tenure, setTenure] = useState(60);
const loan = price - down;
const mr = rate / 12 / 100;
const emi = mr === 0 ? Math.round(loan / tenure) : Math.round(loan * mr * Math.pow(1+mr,tenure) / (Math.pow(1+mr,tenure)-1));
const totalPayable = emi * tenure;
const totalInterest = totalPayable - loan;
return (
<div style={{ fontFamily:'Inter,sans-serif', padding:20, maxWidth:400 }}>
<h3 style={{ fontSize:18, fontWeight:700, marginBottom:16, color:'#E63946' }}>EMI Calculator</h3>
<div style={{ marginBottom:12 }}>
<label style={labelStyle}>Vehicle Price: ₹{price.toLocaleString('en-IN')}</label>
<input type="range" min={200000} max={10000000} step={50000} value={price} onChange={e=>setPrice(+e.target.value)} style={{ width:'100%' }} />
</div>
<div style={{ marginBottom:12 }}>
<label style={labelStyle}>Down Payment: ₹{down.toLocaleString('en-IN')}</label>
<input type="range" min={0} max={price*0.8} step={10000} value={down} onChange={e=>setDown(+e.target.value)} style={{ width:'100%' }} />
</div>
<div style={{ marginBottom:12 }}>
<label style={labelStyle}>Interest Rate: {rate}%</label>
<input type="range" min={7} max={20} step={0.5} value={rate} onChange={e=>setRate(+e.target.value)} style={{ width:'100%' }} />
</div>
<div style={{ marginBottom:16 }}>
<label style={labelStyle}>Tenure: {tenure} months</label>
<input type="range" min={12} max={84} step={6} value={tenure} onChange={e=>setTenure(+e.target.value)} style={{ width:'100%' }} />
</div>
<div style={{ backgroundColor:'#FEF2F2', padding:16, borderRadius:12, textAlign:'center' }}>
<p style={{ fontSize:12, color:'#666' }}>Monthly EMI</p>
<p style={{ fontSize:32, fontWeight:800, color:'#E63946' }}>₹{emi.toLocaleString('en-IN')}</p>
</div>
<div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:8, marginTop:12 }}>
<div style={{ backgroundColor:'#f8f8f8', padding:10, borderRadius:8, textAlign:'center' }}>
<p style={{ fontSize:11, color:'#999' }}>Loan Amount</p>
<p style={{ fontWeight:700, fontSize:14 }}>₹{loan.toLocaleString('en-IN')}</p>
</div>
<div style={{ backgroundColor:'#f8f8f8', padding:10, borderRadius:8, textAlign:'center' }}>
<p style={{ fontSize:11, color:'#999' }}>Total Interest</p>
<p style={{ fontWeight:700, fontSize:14 }}>₹{totalInterest.toLocaleString('en-IN')}</p>
</div>
</div>
<p style={{ fontSize:11, color:'#999', marginTop:12, textAlign:'center' }}>Powered by DreamKaar</p>
</div>
);
}
const labelStyle = { fontSize:13, fontWeight:500, color:'#333', display:'block', marginBottom:4 };