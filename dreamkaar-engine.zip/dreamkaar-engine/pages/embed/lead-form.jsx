import { useState } from 'react';
export default function EmbedLeadForm() {
const [form, setForm] = useState({ customer_name:'', customer_phone:'', customer_city:'', model_interest:'', source:'website' });
const [done, setDone] = useState(false);
const [loading, setLoading] = useState(false);
async function submit(e) {
e.preventDefault(); setLoading(true);
await fetch('/api/leads', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(form) });
setDone(true); setLoading(false);
}
if (done) return (
<div style={{ fontFamily:'Inter,sans-serif', padding:24, textAlign:'center' }}>
<div style={{ fontSize:48, marginBottom:12 }}>✅</div>
<h3 style={{ fontSize:18, fontWeight:700 }}>Thank You!</h3>
<p style={{ color:'#666', marginTop:8 }}>We'll call you within 30 minutes with the best deal.</p>
</div>
);
return (
<div style={{ fontFamily:'Inter,sans-serif', padding:20, maxWidth:400 }}>
<h3 style={{ fontSize:18, fontWeight:700, marginBottom:16, color:'#E63946' }}>Get Best Car Price</h3>
<form onSubmit={submit}>
<input placeholder="Your Name *" required style={inputStyle} value={form.customer_name} onChange={e=>setForm({...form,customer_name:e.target.value})} />
<input placeholder="Phone Number *" required type="tel" style={inputStyle} value={form.customer_phone} onChange={e=>setForm({...form,customer_phone:e.target.value})} />
<input placeholder="City" style={inputStyle} value={form.customer_city} onChange={e=>setForm({...form,customer_city:e.target.value})} />
<input placeholder="Which car are you looking for?" style={inputStyle} value={form.model_interest} onChange={e=>setForm({...form,model_interest:e.target.value})} />
<button type="submit" disabled={loading} style={{ width:'100%', padding:'12px', backgroundColor:'#E63946', color:'white', border:'none', borderRadius:8, fontSize:16, fontWeight:600, cursor:'pointer' }}>
{loading ? 'Submitting...' : 'Get Best Price →'}
</button>
</form>
<p style={{ fontSize:11, color:'#999', marginTop:12, textAlign:'center' }}>Powered by DreamKaar</p>
</div>
);
}
const inputStyle = { width:'100%', padding:'10px 12px', border:'1px solid #ddd', borderRadius:8, marginBottom:12, fontSize:14, boxSizing:'border-box' };