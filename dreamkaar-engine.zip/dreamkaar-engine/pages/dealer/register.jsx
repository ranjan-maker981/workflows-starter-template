import { useState } from 'react';
import { useRouter } from 'next/router';
export default function DealerRegister() {
const router = useRouter();
const [form, setForm] = useState({ name:'', brand:'', city:'', state:'', address:'', contact_person:'', phone:'', email:'', gst:'', models_handled:'' });
const [done, setDone] = useState(false);
const [submitting, setSubmitting] = useState(false);
async function submit() {
setSubmitting(true);
const res = await fetch('/api/dealers/register', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(form) });
if (res.ok) setDone(true);
setSubmitting(false);
}
if (done) return (
<div className="min-h-screen flex items-center justify-center bg-dk-light p-4">
<div className="card max-w-md text-center">
<div className="text-5xl mb-4">✅</div>
<h2 className="text-xl font-bold mb-2">Registration Submitted!</h2>
<p className="text-gray-500">Your dealer registration is under review.</p>
<button onClick={() => router.push('/login')} className="btn-primary mt-6">Go to Login</button>
</div>
</div>
);
return (
<div className="min-h-screen bg-dk-light flex items-center justify-center p-4">
<div className="card w-full max-w-2xl">
<h1 className="text-2xl font-bold text-center mb-1">Dream<span className="text-dk-primary">Kaar</span></h1>
<h2 className="text-lg font-semibold text-center mb-6">Dealer Partner Registration</h2>
<div className="grid md:grid-cols-2 gap-4">
<div><label className="label-field">Dealership Name *</label><input className="input-field" value={form.name} onChange={e=>setForm({...form,name:e.target.value})} /></div>
<div><label className="label-field">Primary Brand *</label><input className="input-field" value={form.brand} onChange={e=>setForm({...form,brand:e.target.value})} /></div>
<div><label className="label-field">City *</label><input className="input-field" value={form.city} onChange={e=>setForm({...form,city:e.target.value})} /></div>
<div><label className="label-field">State</label><input className="input-field" value={form.state} onChange={e=>setForm({...form,state:e.target.value})} /></div>
<div className="md:col-span-2"><label className="label-field">Address</label><input className="input-field" value={form.address} onChange={e=>setForm({...form,address:e.target.value})} /></div>
<div><label className="label-field">Contact Person</label><input className="input-field" value={form.contact_person} onChange={e=>setForm({...form,contact_person:e.target.value})} /></div>
<div><label className="label-field">Phone *</label><input className="input-field" value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})} /></div>
<div><label className="label-field">Email</label><input className="input-field" type="email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})} /></div>
<div><label className="label-field">GST Number</label><input className="input-field" value={form.gst} onChange={e=>setForm({...form,gst:e.target.value})} /></div>
<div className="md:col-span-2"><label className="label-field">Models Handled (comma-separated)</label><input className="input-field" placeholder="e.g. Creta, Venue, i20" value={form.models_handled} onChange={e=>setForm({...form,models_handled:e.target.value})} /></div>
</div>
<div className="flex justify-end mt-6">
<button onClick={submit} disabled={submitting||!form.name||!form.brand||!form.city||!form.phone} className="btn-primary">{submitting?'Submitting...':'Register'}</button>
</div>
</div>
</div>
);
}