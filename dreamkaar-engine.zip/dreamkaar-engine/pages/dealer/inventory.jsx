import { useState, useEffect } from 'react';
import Layout from '../../components/Layout';
import Modal from '../../components/Modal';
export default function DealerInventory() {
const [inventory, setInventory] = useState([]);
const [showAdd, setShowAdd] = useState(false);
const [form, setForm] = useState({ model_name: '', variant_name: '', color: '', quantity: 1, ex_showroom: '', current_discount: '', scheme_details: '' });
useEffect(() => { fetchInventory(); }, []);
async function fetchInventory() {
const res = await fetch('/api/dealers/inventory');
const data = await res.json();
setInventory(data.inventory || []);
}
async function addStock() {
await fetch('/api/dealers/inventory', {
method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(form),
});
setShowAdd(false);
setForm({ model_name: '', variant_name: '', color: '', quantity: 1, ex_showroom: '', current_discount: '', scheme_details: '' });
fetchInventory();
}
async function updateQty(id, quantity) {
await fetch('/api/dealers/inventory', {
method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id, quantity }),
});
fetchInventory();
}
return (
<Layout title="Inventory Management">
<div className="flex justify-between items-center mb-6">
<p className="text-gray-500">Update your stock so DreamKaar can route orders accurately.</p>
<button onClick={() => setShowAdd(true)} className="btn-primary">+ Add Stock</button>
</div>
<div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
{inventory.length === 0 ? (
<div className="col-span-full card text-center py-12 text-gray-400">No inventory added yet</div>
) : inventory.map(item => (
<div key={item.id} className="card">
<div className="flex justify-between items-start mb-2">
<div>
<p className="font-semibold">{item.model_name}</p>
<p className="text-xs text-gray-400">{item.variant_name} • {item.color}</p>
</div>
<span className={`badge ${item.quantity > 0 ? 'badge-success' : 'badge-danger'}`}>
{item.quantity > 0 ? `${item.quantity} in stock` : 'Out of stock'}
</span>
</div>
{item.ex_showroom > 0 && <p className="text-sm">Ex-showroom: ₹{item.ex_showroom.toLocaleString('en-IN')}</p>}
{item.current_discount > 0 && <p className="text-sm text-dk-success">Discount: ₹{item.current_discount.toLocaleString('en-IN')}</p>}
{item.scheme_details && <p className="text-xs text-gray-400 mt-1">{item.scheme_details}</p>}
<div className="flex items-center gap-2 mt-3 pt-3 border-t">
<button onClick={() => updateQty(item.id, Math.max(0, item.quantity - 1))} className="btn-ghost text-sm px-2 py-1">-</button>
<span className="font-medium">{item.quantity}</span>
<button onClick={() => updateQty(item.id, item.quantity + 1)} className="btn-ghost text-sm px-2 py-1">+</button>
</div>
</div>
))}
</div>
<Modal isOpen={showAdd} onClose={() => setShowAdd(false)} title="Add Stock Item">
<div className="grid md:grid-cols-2 gap-4">
<div><label className="label-field">Model *</label><input className="input-field" value={form.model_name} onChange={e=>setForm({...form,model_name:e.target.value})} /></div>
<div><label className="label-field">Variant</label><input className="input-field" value={form.variant_name} onChange={e=>setForm({...form,variant_name:e.target.value})} /></div>
<div><label className="label-field">Color</label><input className="input-field" value={form.color} onChange={e=>setForm({...form,color:e.target.value})} /></div>
<div><label className="label-field">Quantity</label><input className="input-field" type="number" value={form.quantity} onChange={e=>setForm({...form,quantity:parseInt(e.target.value)||0})} /></div>
<div><label className="label-field">Ex-Showroom (₹)</label><input className="input-field" type="number" value={form.ex_showroom} onChange={e=>setForm({...form,ex_showroom:e.target.value})} /></div>
<div><label className="label-field">Current Discount (₹)</label><input className="input-field" type="number" value={form.current_discount} onChange={e=>setForm({...form,current_discount:e.target.value})} /></div>
<div className="md:col-span-2"><label className="label-field">Scheme Details</label><textarea className="input-field" rows={2} value={form.scheme_details} onChange={e=>setForm({...form,scheme_details:e.target.value})} /></div>
</div>
<div className="flex justify-end gap-3 mt-6">
<button onClick={() => setShowAdd(false)} className="btn-ghost">Cancel</button>
<button onClick={addStock} disabled={!form.model_name} className="btn-primary">Add</button>
</div>
</Modal>
</Layout>
);
}