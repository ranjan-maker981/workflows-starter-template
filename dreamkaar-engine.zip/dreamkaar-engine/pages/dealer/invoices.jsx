import Layout from '../../components/Layout';
export default function DealerInvoices() {
return <Layout title="Invoices"><div className="card"><p className="text-gray-400 text-center py-12">Upload and manage invoices for completed deliveries.</p></div></Layout>;
}