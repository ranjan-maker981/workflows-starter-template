import Layout from '../../components/Layout';
export default function DealerPerf() {
return <Layout title="My Performance"><div className="card"><p className="text-gray-400 text-center py-12">Your dealer scorecard: delivery speed, discount consistency, response time, and reliability rating.</p></div></Layout>;
}