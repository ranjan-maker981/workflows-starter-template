import { useState, useEffect } from 'react';
import Layout from '../../components/Layout';
import DataTable from '../../components/DataTable';
export default function DealerOrders() {
const [orders, setOrders] = useState([]);
useEffect(() => { fetch('/api/dealers/orders').then(r=>r.json()).then(d=>setOrders(d.orders||[])); }, []);
async function updateStatus(id, status) {
await fetch('/api/deals/' + id, { method: 'PATCH', headers: {'Content-Type':'application/json'}, body: JSON.stringify({ status }) });
setOrders(prev => prev.map(o => o.id === id ? { ...o, status } : o));
}
const columns = [
{ key: 'customer_name', label: 'Customer', render: v => <span className="font-medium">{v}</span> },
{ key: 'model_name', label: 'Model' },
{ key: 'variant_name', label: 'Variant' },
{ key: 'color', label: 'Color' },
{ key: 'status', label: 'Status', render: (v, row) => (
<select className="select-field text-xs py-1 w-auto" value={v} onChange={e => updateStatus(row.id, e.target.value)}>
<option value="booked">Booked</option>
<option value="vehicle_allocated">Allocated</option>
<option value="dispatched">Dispatched</option>
<option value="delivered">Delivered</option>
</select>
)},
{ key: 'created_at', label: 'Date', render: v => v ? new Date(v).toLocaleDateString('en-IN') : '-' },
];
return (
<Layout title="Orders">
<DataTable columns={columns} data={orders} emptyMessage="No orders yet" />
</Layout>
);
}