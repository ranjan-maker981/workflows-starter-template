import { useState, useEffect } from 'react';
import Layout from '../../components/Layout';
import { StatCard } from '../../components/Charts';
export default function DealerDashboard() {
const [stats, setStats] = useState({});
const [loading, setLoading] = useState(true);
useEffect(() => {
fetch('/api/dealers/dashboard').then(r => r.json()).then(d => { setStats(d); setLoading(false); });
}, []);
if (loading) return <Layout title="Dealer Dashboard"><div className="animate-pulse">Loading...</div></Layout>;
return (
<Layout title="Dealer Dashboard">
<div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
<StatCard icon="📋" label="Active Orders" value={stats.activeOrders || 0} />
<StatCard icon="✅" label="Delivered" value={stats.delivered || 0} />
<StatCard icon="📦" label="Stock Items" value={stats.stockItems || 0} />
<StatCard icon="⭐" label="Rating" value={stats.rating || '-'} suffix="/5" />
</div>
<div className="grid md:grid-cols-2 gap-6">
<div className="card">
<h3 className="text-sm font-semibold text-gray-600 mb-4">Pending Orders</h3>
{(stats.pendingOrders || []).length === 0 ? (
<p className="text-gray-400 text-center py-8">No pending orders</p>
) : (
<div className="space-y-3">
{stats.pendingOrders.map(o => (
<div key={o.id} className="p-3 bg-gray-50 rounded-lg flex justify-between items-center">
<div>
<p className="text-sm font-medium">{o.customer_name}</p>
<p className="text-xs text-gray-400">{o.model_name} • {o.variant_name || ''}</p>
</div>
<span className="badge-warning capitalize">{(o.status||'').replace(/_/g,' ')}</span>
</div>
))}
</div>
)}
</div>
<div className="card">
<h3 className="text-sm font-semibold text-gray-600 mb-4">Recent Deliveries</h3>
{(stats.recentDeliveries || []).length === 0 ? (
<p className="text-gray-400 text-center py-8">No deliveries yet</p>
) : (
<div className="space-y-3">
{stats.recentDeliveries.map(d => (
<div key={d.id} className="p-3 bg-green-50 rounded-lg flex justify-between items-center">
<div>
<p className="text-sm font-medium">{d.customer_name}</p>
<p className="text-xs text-gray-400">{d.model_name}</p>
</div>
<span className="badge-success">Delivered</span>
</div>
))}
</div>
)}
</div>
</div>
</Layout>
);
}