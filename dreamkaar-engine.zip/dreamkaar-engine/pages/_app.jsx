import '../styles/globals.css';
import Head from 'next/head';
import { useState, useEffect, createContext, useContext } from 'react';
export const AuthContext = createContext(null);
export function useAuth() {
return useContext(AuthContext);
}
export default function App({ Component, pageProps }) {
const [user, setUser] = useState(null);
const [loading, setLoading] = useState(true);
useEffect(() => {
checkSession();
}, []);
async function checkSession() {
try {
const res = await fetch('/api/auth/session');
if (res.ok) {
const data = await res.json();
setUser(data.user);
}
} catch (e) {
console.error('Session check failed:', e);
}
setLoading(false);
}
async function logout() {
await fetch('/api/auth/logout', { method: 'POST' });
setUser(null);
window.location.href = '/login';
}
return (
<AuthContext.Provider value={{ user, setUser, loading, logout }}>
<Head>
<title>DreamKaar Engine</title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<meta name="theme-color" content="#E63946" />
<link rel="manifest" href="/manifest.json" />
</Head>
<Component {...pageProps} />
</AuthContext.Provider>
);
}