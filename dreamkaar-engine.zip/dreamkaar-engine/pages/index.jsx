import { useEffect } from 'react';
import { useRouter } from 'next/router';
import { useAuth } from './_app';
export default function Home() {
const { user, loading } = useAuth();
const router = useRouter();
useEffect(() => {
if (!loading) {
if (!user) router.push('/login');
else {
const homes = {
admin: '/admin', sales: '/sales', dsa: '/dsa',
dealer: '/dealer', nbfc: '/nbfc', fleet: '/fleet', customer: '/customer',
};
router.push(homes[user.role] || '/admin');
}
}
}, [user, loading]);
return (
<div className="min-h-screen flex items-center justify-center bg-dk-light">
<div className="animate-pulse text-dk-primary text-xl font-semibold">Loading DreamKaar...</div>
</div>
);
}