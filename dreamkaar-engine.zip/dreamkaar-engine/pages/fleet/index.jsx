import Layout from '../../components/Layout';
import Link from 'next/link';
export default function FleetDashboard() {
return (
<Layout title="Fleet & Corporate">
<div className="max-w-2xl mx-auto grid gap-4">
<Link href="/fleet/inquiry" className="card-hover text-center py-8">
<div className="text-4xl mb-3">🚛</div>
<h3 className="text-lg font-semibold">New Fleet Inquiry</h3>
<p className="text-sm text-gray-500 mt-1">Submit a bulk vehicle requirement</p>
</Link>
<Link href="/fleet/tco-calculator" className="card-hover text-center py-8">
<div className="text-4xl mb-3">🧮</div>
<h3 className="text-lg font-semibold">TCO Calculator</h3>
<p className="text-sm text-gray-500 mt-1">Calculate total cost of ownership</p>
</Link>
<Link href="/fleet/orders" className="card-hover text-center py-8">
<div className="text-4xl mb-3">📋</div>
<h3 className="text-lg font-semibold">My Orders</h3>
<p className="text-sm text-gray-500 mt-1">Track your fleet orders</p>
</Link>
</div>
</Layout>
);
}