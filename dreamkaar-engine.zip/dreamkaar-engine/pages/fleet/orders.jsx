import Layout from '../../components/Layout';
export default function FleetOrders() {
return <Layout title="My Fleet Orders"><div className="card"><p className="text-gray-400 text-center py-12">Your fleet orders will appear here once inquiries are processed.</p></div></Layout>;
}