import { useState } from 'react';
import Layout from '../../components/Layout';
import { calculateTCO } from '../../lib/onroad-calculator';
export default function TCOCalculator() {
const [form, setForm] = useState({ onRoadPrice: 1000000, fuelCostPerKm: 6, avgKmPerMonth: 2000, maintenancePerYear: 15000, driverSalaryPerMonth: 15000, insurancePerYear: 25000, depreciationRate: 15, tenureYears: 5 });
const [result, setResult] = useState(null);
function calculate() {
// Client-side calculation
const r = {};
const { onRoadPrice, fuelCostPerKm, avgKmPerMonth, maintenancePerYear, driverSalaryPerMonth, insurancePerYear, depreciationRate, tenureYears } = form;
r.purchase_cost = onRoadPrice;
r.total_fuel = fuelCostPerKm * avgKmPerMonth * 12 * tenureYears;
r.total_maintenance = maintenancePerYear * tenureYears;
r.total_driver = driverSalaryPerMonth * 12 * tenureYears;
r.total_insurance = insurancePerYear * tenureYears;
r.depreciation = Math.round(onRoadPrice * (1 - Math.pow(1 - depreciationRate / 100, tenureYears)));
r.resale_value = onRoadPrice - r.depreciation;
r.total_cost = onRoadPrice + r.total_fuel + r.total_maintenance + r.total_driver + r.total_insurance;
r.total_km = avgKmPerMonth * 12 * tenureYears;
r.cost_per_km = Math.round((r.total_cost / r.total_km) * 100) / 100;
r.cost_per_month = Math.round(r.total_cost / (tenureYears * 12));
setResult(r);
}
return (
<Layout title="TCO Calculator">
<div className="grid md:grid-cols-2 gap-6 max-w-4xl">
<div className="card">
<h3 className="font-semibold mb-4">Input Parameters</h3>
<div className="space-y-3">
{[
{ key: 'onRoadPrice', label: 'Vehicle On-Road Price (₹)', step: 10000 },
{ key: 'fuelCostPerKm', label: 'Fuel Cost / km (₹)', step: 0.5 },
{ key: 'avgKmPerMonth', label: 'Avg km / month', step: 100 },
{ key: 'maintenancePerYear', label: 'Maintenance / year (₹)', step: 1000 },
{ key: 'driverSalaryPerMonth', label: 'Driver Salary / month (₹)', step: 1000 },
{ key: 'insurancePerYear', label: 'Insurance / year (₹)', step: 1000 },
{ key: 'depreciationRate', label: 'Depreciation Rate (%)', step: 1 },
{ key: 'tenureYears', label: 'Ownership Period (years)', step: 1 },
].map(f => (
<div key={f.key}>
<label className="label-field">{f.label}</label>
<input className="input-field" type="number" step={f.step} value={form[f.key]}
onChange={e => setForm({ ...form, [f.key]: parseFloat(e.target.value) || 0 })} />
</div>
))}
</div>
<button onClick={calculate} className="btn-primary w-full mt-4">Calculate TCO</button>
</div>
{result && (
<div className="card">
<h3 className="font-semibold mb-4">Total Cost of Ownership</h3>
<div className="space-y-3">
{[
{ label: 'Purchase Cost', value: result.purchase_cost },
{ label: 'Total Fuel', value: result.total_fuel },
{ label: 'Total Maintenance', value: result.total_maintenance },
{ label: 'Total Driver Cost', value: result.total_driver },
{ label: 'Total Insurance', value: result.total_insurance },
].map((item, i) => (
<div key={i} className="flex justify-between text-sm py-1">
<span className="text-gray-500">{item.label}</span>
<span>₹{item.value.toLocaleString('en-IN')}</span>
</div>
))}
<div className="border-t-2 pt-3 mt-3">
<div className="flex justify-between font-bold text-lg"><span>Total Cost</span><span>₹{result.total_cost.toLocaleString('en-IN')}</span></div>
</div>
<div className="grid grid-cols-2 gap-3 mt-4">
<div className="bg-dk-primary/5 p-3 rounded-xl text-center">
<p className="text-2xl font-bold text-dk-primary">₹{result.cost_per_km}</p>
<p className="text-xs text-gray-500">Cost / km</p>
</div>
<div className="bg-dk-secondary/5 p-3 rounded-xl text-center">
<p className="text-2xl font-bold text-dk-secondary">₹{result.cost_per_month.toLocaleString('en-IN')}</p>
<p className="text-xs text-gray-500">Cost / month</p>
</div>
</div>
<div className="mt-3 p-3 bg-green-50 rounded-xl text-center">
<p className="text-sm text-gray-500">Estimated Resale Value</p>
<p className="text-lg font-bold text-dk-success">₹{result.resale_value.toLocaleString('en-IN')}</p>
</div>
</div>
</div>
)}
</div>
</Layout>
);
}