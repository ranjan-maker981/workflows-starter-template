import { useState } from 'react';
import Layout from '../../components/Layout';
export default function FleetInquiry() {
const [form, setForm] = useState({ company_name:'', contact_person:'', phone:'', email:'', gst:'', city:'', vehicle_types:'', quantity:'', budget_per_vehicle:'', delivery_timeline:'', notes:'' });
const [done, setDone] = useState(false);
async function submit() {
const res = await fetch('/api/fleet/inquiry', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(form) });
if (res.ok) setDone(true);
}
if (done) return <Layout title="Fleet Inquiry"><div className="card max-w-md mx-auto text-center py-12"><div className="text-5xl mb-4">✅</div><h2 className="text-xl font-bold">Inquiry Submitted!</h2><p className="text-gray-500 mt-2">Our fleet team will contact you within 24 hours.</p></div></Layout>;
return (
<Layout title="New Fleet Inquiry">
<div className="card max-w-2xl">
<div className="grid md:grid-cols-2 gap-4">
<div><label className="label-field">Company Name *</label><input className="input-field" value={form.company_name} onChange={e=>setForm({...form,company_name:e.target.value})} /></div>
<div><label className="label-field">Contact Person *</label><input className="input-field" value={form.contact_person} onChange={e=>setForm({...form,contact_person:e.target.value})} /></div>
<div><label className="label-field">Phone *</label><input className="input-field" value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})} /></div>
<div><label className="label-field">Email</label><input className="input-field" type="email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})} /></div>
<div><label className="label-field">GST Number</label><input className="input-field" value={form.gst} onChange={e=>setForm({...form,gst:e.target.value})} /></div>
<div><label className="label-field">City</label><input className="input-field" value={form.city} onChange={e=>setForm({...form,city:e.target.value})} /></div>
<div><label className="label-field">Vehicle Types Needed</label><input className="input-field" placeholder="e.g. Tata Ace x10, Eicher Pro x5" value={form.vehicle_types} onChange={e=>setForm({...form,vehicle_types:e.target.value})} /></div>
<div><label className="label-field">Total Quantity</label><input className="input-field" type="number" value={form.quantity} onChange={e=>setForm({...form,quantity:e.target.value})} /></div>
<div><label className="label-field">Budget / Vehicle (₹)</label><input className="input-field" type="number" value={form.budget_per_vehicle} onChange={e=>setForm({...form,budget_per_vehicle:e.target.value})} /></div>
<div><label className="label-field">Delivery Timeline</label><input className="input-field" placeholder="e.g. Within 30 days" value={form.delivery_timeline} onChange={e=>setForm({...form,delivery_timeline:e.target.value})} /></div>
<div className="md:col-span-2"><label className="label-field">Notes</label><textarea className="input-field" rows={3} value={form.notes} onChange={e=>setForm({...form,notes:e.target.value})} /></div>
</div>
<div className="flex justify-end mt-6"><button onClick={submit} disabled={!form.company_name||!form.contact_person||!form.phone} className="btn-primary">Submit Inquiry</button></div>
</div>
</Layout>
);
}