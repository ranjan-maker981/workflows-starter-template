import Layout from '../../components/Layout';
export default function CustomerDocs() {
return <Layout title="My Documents"><div className="card"><p className="text-gray-400 text-center py-12">Your vehicle documents (insurance, RC, invoice) will appear here after delivery.</p></div></Layout>;
}