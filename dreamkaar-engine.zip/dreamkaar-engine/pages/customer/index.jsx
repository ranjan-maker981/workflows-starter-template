import { useState, useEffect } from 'react';
import Layout from '../../components/Layout';
import { useAuth } from '../_app';
export default function CustomerDashboard() {
const { user } = useAuth();
const [deals, setDeals] = useState([]);
const [referral, setReferral] = useState(null);
useEffect(() => {
fetch('/api/customer/my-deals').then(r=>r.json()).then(d => { setDeals(d.deals||[]); setReferral(d.referral); });
}, []);
return (
<Layout title="My Dashboard">
<div className="max-w-3xl mx-auto">
<div className="card mb-6">
<h3 className="text-lg font-semibold mb-2">Welcome, {user?.name || 'Customer'}!</h3>
<p className="text-gray-500 text-sm">Track your car purchase journey here.</p>
</div>
{deals.length === 0 ? (
<div className="card text-center py-12">
<p className="text-gray-400 text-lg mb-2">No active orders</p>
<p className="text-gray-400 text-sm">Once you book a car through DreamKaar, you'll see your order here.</p>
</div>
) : deals.map(deal => (
<div key={deal.id} className="card mb-4">
<div className="flex justify-between items-start mb-4">
<div>
<h4 className="text-lg font-semibold">{deal.model_name} {deal.variant_name || ''}</h4>
<p className="text-sm text-gray-400">{deal.color || ''}</p>
</div>
<span className={`badge ${deal.status==='delivered'?'badge-success':'badge-info'}`} style={{textTransform:'capitalize'}}>
{(deal.status||'').replace(/_/g,' ')}
</span>
</div>
<div className="grid grid-cols-2 gap-3 text-sm">
<div><span className="text-gray-400">On-Road Price</span><p className="font-medium">₹{(deal.on_road_price||0).toLocaleString('en-IN')}</p></div>
<div><span className="text-gray-400">Your Discount</span><p className="font-medium text-dk-success">₹{(deal.customer_discount||0).toLocaleString('en-IN')}</p></div>
{deal.emi_amount > 0 && <div><span className="text-gray-400">Monthly EMI</span><p className="font-medium">₹{deal.emi_amount.toLocaleString('en-IN')}</p></div>}
{deal.delivery_date_expected && <div><span className="text-gray-400">Expected Delivery</span><p className="font-medium">{deal.delivery_date_expected}</p></div>}
</div>
{/* Delivery Progress */}
<div className="mt-4 pt-4 border-t">
<DeliveryProgress status={deal.status} />
</div>
</div>
))}
{referral && (
<div className="card mt-6 border-2 border-dk-primary/20">
<h3 className="font-semibold mb-2">Your Referral Code</h3>
<div className="bg-dk-primary/5 p-4 rounded-xl text-center">
<p className="text-2xl font-bold text-dk-primary tracking-wider">{referral.code}</p>
<p className="text-sm text-gray-500 mt-2">Share this code — your friend gets ₹{referral.referee_discount} off, you earn ₹{referral.referral_reward}!</p>
</div>
<div className="grid grid-cols-3 gap-3 mt-4 text-center text-sm">
<div><p className="font-bold">{referral.total_referrals}</p><p className="text-gray-400">Referrals</p></div>
<div><p className="font-bold">{referral.total_conversions}</p><p className="text-gray-400">Converted</p></div>
<div><p className="font-bold">₹{(referral.total_earned||0).toLocaleString('en-IN')}</p><p className="text-gray-400">Earned</p></div>
</div>
</div>
)}
</div>
</Layout>
);
}
function DeliveryProgress({ status }) {
const stages = ['booked','finance_approved','invoice_generated','vehicle_allocated','dispatched','delivered'];
const currentIdx = stages.indexOf(status);
return (
<div className="flex items-center gap-1">
{stages.map((s, i) => (
<div key={s} className="flex-1 flex items-center">
<div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${i <= currentIdx ? 'bg-dk-success text-white' : 'bg-gray-200 text-gray-400'}`}>
{i <= currentIdx ? '✓' : i + 1}
</div>
{i < stages.length - 1 && <div className={`flex-1 h-1 mx-1 rounded ${i < currentIdx ? 'bg-dk-success' : 'bg-gray-200'}`} />}
</div>
))}
</div>
);
}