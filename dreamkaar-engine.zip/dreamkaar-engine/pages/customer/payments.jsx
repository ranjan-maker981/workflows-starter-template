import Layout from '../../components/Layout';
export default function CustomerPayments() {
return <Layout title="My Payments"><div className="card"><p className="text-gray-400 text-center py-12">Payment history and receipts will appear here.</p></div></Layout>;
}