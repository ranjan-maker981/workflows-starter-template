import { useState, useRef, useEffect } from 'react';
import { auth, RecaptchaVerifier, signInWithPhoneNumber } from '../lib/firebase';
import { useAuth } from './_app';
import { useRouter } from 'next/router';
const DEV_ROLES = ['admin', 'sales', 'dsa', 'dealer', 'nbfc', 'fleet', 'customer'];
export default function Login() {
const { user, setUser } = useAuth();
const router = useRouter();
const [step, setStep] = useState('phone');
const [phone, setPhone] = useState('');
const [otp, setOtp] = useState('');
const [confirmation, setConfirmation] = useState(null);
const [error, setError] = useState('');
const [loading, setLoading] = useState(false);
const [showDev, setShowDev] = useState(false);
const recaptchaRef = useRef(null);
const roleHomes = {
admin: '/admin', sales: '/sales', dsa: '/dsa',
dealer: '/dealer', nbfc: '/nbfc', fleet: '/fleet', customer: '/customer',
};
useEffect(() => {
if (user) router.push(roleHomes[user.role] || '/admin');
}, [user]);
useEffect(() => {
if (step === 'phone' && typeof window !== 'undefined' && !recaptchaRef.current) {
try {
recaptchaRef.current = new RecaptchaVerifier(auth, 'recaptcha-container', { size: 'invisible' });
} catch (e) { console.error('Recaptcha error:', e); }
}
}, [step]);
async function sendOTP() {
setError(''); setLoading(true);
try {
let p = phone.trim();
if (!p.startsWith('+')) p = '+91' + p.replace(/^0/, '');
const result = await signInWithPhoneNumber(auth, p, recaptchaRef.current);
setConfirmation(result);
setStep('otp');
} catch (e) {
setError(e.message || 'Failed to send OTP');
}
setLoading(false);
}
async function verifyOTP() {
setError(''); setLoading(true);
try {
const result = await confirmation.confirm(otp);
const idToken = await result.user.getIdToken();
const res = await fetch('/api/auth/verify-otp', {
method: 'POST',
headers: { 'Content-Type': 'application/json' },
body: JSON.stringify({ idToken, phone: result.user.phoneNumber }),
});
const data = await res.json();
if (data.error) setError(data.error);
else setUser(data.user);
} catch (e) {
setError('Invalid OTP. Try again.');
}
setLoading(false);
}
async function devLogin(role) {
setLoading(true);
const res = await fetch('/api/auth/login', {
method: 'POST',
headers: { 'Content-Type': 'application/json' },
body: JSON.stringify({ phone: `+91${role}0000000`, role, devMode: true }),
});
const data = await res.json();
if (data.user) setUser(data.user);
setLoading(false);
}
return (
<div className="min-h-screen bg-gradient-to-br from-dk-secondary via-dk-dark to-dk-secondary flex items-center justify-center p-4">
<div className="w-full max-w-md">
<div className="text-center mb-8">
<h1 className="text-4xl font-bold text-white">
Dream<span className="text-dk-primary">Kaar</span>
</h1>
<p className="text-gray-400 mt-2">Business Operating System</p>
</div>
<div className="card">
{step === 'phone' && (
<>
<h2 className="text-xl font-semibold mb-6">Login with Phone</h2>
{error && <div className="bg-red-50 text-red-600 p-3 rounded-lg mb-4 text-sm">{error}</div>}
<div className="mb-4">
<label className="label-field">Phone Number</label>
<div className="flex gap-2">
<span className="input-field w-16 text-center bg-gray-50">+91</span>
<input
type="tel" className="input-field" placeholder="9876543210"
value={phone} onChange={e => setPhone(e.target.value)}
maxLength={10}
/>
</div>
</div>
<button onClick={sendOTP} disabled={loading || phone.length < 10} className="btn-primary w-full">
{loading ? 'Sending OTP...' : 'Send OTP'}
</button>
</>
)}
{step === 'otp' && (
<>
<h2 className="text-xl font-semibold mb-2">Enter OTP</h2>
<p className="text-gray-500 text-sm mb-6">Sent to +91{phone}</p>
{error && <div className="bg-red-50 text-red-600 p-3 rounded-lg mb-4 text-sm">{error}</div>}
<div className="mb-4">
<label className="label-field">6-digit OTP</label>
<input
type="text" className="input-field text-center text-2xl tracking-widest"
placeholder="------" value={otp} onChange={e => setOtp(e.target.value)}
maxLength={6}
/>
</div>
<button onClick={verifyOTP} disabled={loading || otp.length < 6} className="btn-primary w-full">
{loading ? 'Verifying...' : 'Verify & Login'}
</button>
<button onClick={() => { setStep('phone'); setOtp(''); }} className="btn-ghost w-full mt-2">
Change Number
</button>
</>
)}
<div id="recaptcha-container"></div>
</div>
{/* Dev Mode Toggle */}
<div className="mt-6 text-center">
<button onClick={() => setShowDev(!showDev)} className="text-gray-500 text-xs hover:text-gray-300">
{showDev ? 'Hide' : 'Show'} Dev Login
</button>
{showDev && (
<div className="mt-3 grid grid-cols-2 gap-2">
{DEV_ROLES.map(role => (
<button key={role} onClick={() => devLogin(role)}
className="bg-white/10 text-white px-3 py-2 rounded-lg text-sm hover:bg-white/20 capitalize">
{role}
</button>
))}
</div>
)}
</div>
</div>
</div>
);
}