import { useState, useEffect } from 'react';
import Layout from '../../components/Layout';
import { StatCard } from '../../components/Charts';
import { useAuth } from '../_app';
export default function SalesDashboard() {
const { user } = useAuth();
const [stats, setStats] = useState({});
useEffect(() => {
fetch('/api/leads?limit=500').then(r=>r.json()).then(d => {
const leads = d.leads || [];
const today = new Date().toISOString().split('T')[0];
setStats({
total: leads.length,
new: leads.filter(l=>l.status==='new'||l.status==='assigned').length,
followUpsToday: leads.filter(l=>l.next_follow_up&&l.next_follow_up.startsWith(today)).length,
overdue: leads.filter(l=>l.next_follow_up&&l.next_follow_up<new Date().toISOString()&&!['delivered','lost'].includes(l.status)).length,
hot: leads.filter(l=>l.score>=80).length,
leads,
});
});
}, []);
return (
<Layout title={`Welcome, ${user?.name || 'Sales'}`}>
<div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6">
<StatCard icon="👥" label="My Leads" value={stats.total||0} />
<StatCard icon="🆕" label="New/Assigned" value={stats.new||0} />
<StatCard icon="📞" label="Follow-ups Today" value={stats.followUpsToday||0} />
<StatCard icon="⏰" label="Overdue" value={stats.overdue||0} />
<StatCard icon="🔥" label="Hot Leads" value={stats.hot||0} />
</div>
<div className="card">
<h3 className="text-sm font-semibold text-gray-600 mb-4">My Recent Leads</h3>
<div className="space-y-2">
{(stats.leads||[]).slice(0,15).map(l => (
<div key={l.id} className="flex items-center justify-between p-3 hover:bg-gray-50 rounded-lg">
<div>
<p className="text-sm font-medium">{l.customer_name}</p>
<p className="text-xs text-gray-400">{l.model_interest} • {l.customer_city}</p>
</div>
<div className="flex items-center gap-2">
<span className={`badge ${l.priority==='high'?'badge-danger':l.priority==='medium'?'badge-warning':'badge-neutral'}`}>{l.priority}</span>
<span className="badge-info capitalize">{(l.status||'').replace(/_/g,' ')}</span>
</div>
</div>
))}
</div>
</div>
</Layout>
);
}