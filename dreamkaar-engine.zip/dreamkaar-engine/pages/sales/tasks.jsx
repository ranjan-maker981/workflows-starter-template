import Pipeline from '../admin/pipeline';
export default Pipeline; // Same pipeline view, filtered by API