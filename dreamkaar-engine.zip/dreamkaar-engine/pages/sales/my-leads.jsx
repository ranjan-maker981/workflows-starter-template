import AdminLeads from '../admin/leads';
export default AdminLeads; // Sales sees same leads page but filtered to their assigned leads via API