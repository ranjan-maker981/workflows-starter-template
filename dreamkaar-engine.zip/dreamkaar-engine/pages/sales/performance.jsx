import Layout from '../../components/Layout';
export default function Performance() {
return <Layout title="My Performance"><div className="card"><p className="text-gray-400 text-center py-12">Your conversion metrics, response time, and commission breakdown will appear here.</p></div></Layout>;
}