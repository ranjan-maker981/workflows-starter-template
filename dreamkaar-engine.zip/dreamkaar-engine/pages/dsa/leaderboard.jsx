import { useState, useEffect } from 'react';
import Layout from '../../components/Layout';
export default function DSALeaderboard() {
const [board, setBoard] = useState([]);
const [loading, setLoading] = useState(true);
useEffect(() => {
fetch('/api/dsa/leaderboard').then(r => r.json()).then(d => { setBoard(d.leaderboard || []); setLoading(false); });
}, []);
return (
<Layout title="DSA Leaderboard">
<div className="card max-w-2xl mx-auto">
<h3 className="text-lg font-semibold mb-6 text-center">Top Performers This Month</h3>
{board.length === 0 ? (
<p className="text-gray-400 text-center py-8">No data yet</p>
) : (
<div className="space-y-3">
{board.map((dsa, i) => (
<div key={dsa.id} className={`flex items-center gap-4 p-4 rounded-xl ${i === 0 ? 'bg-amber-50 border border-amber-200' : i === 1 ? 'bg-gray-50 border border-gray-200' : i === 2 ? 'bg-orange-50 border border-orange-200' : 'bg-white border border-gray-100'}`}>
<div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-lg ${i === 0 ? 'bg-amber-400 text-white' : i === 1 ? 'bg-gray-400 text-white' : i === 2 ? 'bg-orange-400 text-white' : 'bg-gray-200 text-gray-600'}`}>
{i + 1}
</div>
<div className="flex-1">
<p className="font-semibold">{dsa.name}</p>
<p className="text-xs text-gray-400">{dsa.city}</p>
</div>
<div className="text-right">
<p className="font-bold text-dk-primary">{dsa.total_conversions} deals</p>
<p className="text-xs text-gray-400">{dsa.total_leads} leads</p>
</div>
</div>
))}
</div>
)}
</div>
</Layout>
);
}