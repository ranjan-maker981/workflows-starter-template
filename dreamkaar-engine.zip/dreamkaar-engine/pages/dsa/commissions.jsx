import { useState, useEffect } from 'react';
import Layout from '../../components/Layout';
import { StatCard } from '../../components/Charts';
export default function DSACommissions() {
const [data, setData] = useState({ commissions: [], summary: {} });
const [loading, setLoading] = useState(true);
useEffect(() => {
fetch('/api/dsa/commissions').then(r => r.json()).then(d => { setData(d); setLoading(false); });
}, []);
return (
<Layout title="My Commissions">
<div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
<StatCard icon="💰" label="Total Earned" value={`₹${(data.summary?.totalEarned || 0).toLocaleString('en-IN')}`} />
<StatCard icon="✅" label="Paid" value={`₹${(data.summary?.totalPaid || 0).toLocaleString('en-IN')}`} />
<StatCard icon="⏳" label="Pending" value={`₹${(data.summary?.pending || 0).toLocaleString('en-IN')}`} />
<StatCard icon="🤝" label="Total Deals" value={data.summary?.totalDeals || 0} />
</div>
<div className="card">
<h3 className="text-sm font-semibold text-gray-600 mb-4">Commission History</h3>
{(data.commissions || []).length === 0 ? (
<p className="text-gray-400 text-center py-8">No commissions yet. Convert leads to earn!</p>
) : (
<div className="overflow-x-auto">
<table className="w-full">
<thead><tr className="table-header">
<th className="px-4 py-3">Deal</th><th className="px-4 py-3">Amount</th>
<th className="px-4 py-3">Status</th><th className="px-4 py-3">Date</th>
</tr></thead>
<tbody>
{data.commissions.map(c => (
<tr key={c.id} className="hover:bg-gray-50">
<td className="table-cell">{c.deal_id?.slice(0,8) || '-'}</td>
<td className="table-cell font-medium">₹{(c.amount||0).toLocaleString('en-IN')}</td>
<td className="table-cell"><span className={c.status==='paid'?'badge-success':'badge-warning'}>{c.status}</span></td>
<td className="table-cell">{c.created_at ? new Date(c.created_at).toLocaleDateString('en-IN') : '-'}</td>
</tr>
))}
</tbody>
</table>
</div>
)}
</div>
</Layout>
);
}