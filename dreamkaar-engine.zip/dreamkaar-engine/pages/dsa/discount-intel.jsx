import { useState, useEffect } from 'react';
import Layout from '../../components/Layout';
export default function DSADiscountIntel() {
const [models, setModels] = useState([]);
const [search, setSearch] = useState('');
useEffect(() => {
fetch('/api/vehicles?limit=200').then(r => r.json()).then(d => setModels(d.models || []));
}, []);
const filtered = models.filter(m =>
m.name.toLowerCase().includes(search.toLowerCase()) || (m.brand_name||'').toLowerCase().includes(search.toLowerCase())
);
return (
<Layout title="Discount Intelligence">
<div className="card mb-4">
<p className="text-sm text-gray-500 mb-3">Use this to check approximate discounts available on models when talking to customers. These are indicative — final discount confirmed by admin.</p>
<input className="input-field max-w-md" placeholder="Search brand or model..." value={search} onChange={e => setSearch(e.target.value)} />
</div>
<div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
{filtered.slice(0, 30).map(m => (
<div key={m.id} className="card-hover">
<div className="flex justify-between items-start mb-2">
<div>
<p className="text-xs text-gray-400">{m.brand_name}</p>
<p className="font-semibold">{m.name}</p>
</div>
<span className="badge-neutral">{m.segment}</span>
</div>
<p className="text-sm text-gray-600">₹{(m.ex_showroom_min||0).toLocaleString('en-IN')} - ₹{(m.ex_showroom_max||0).toLocaleString('en-IN')}</p>
<div className="mt-2 pt-2 border-t">
<p className="text-xs text-gray-400">Est. Discount Range</p>
<p className="text-sm font-medium text-dk-success">
₹{Math.round((m.ex_showroom_min||0)*0.02).toLocaleString('en-IN')} - ₹{Math.round((m.ex_showroom_max||0)*0.07).toLocaleString('en-IN')}
</p>
</div>
</div>
))}
</div>
</Layout>
);
}