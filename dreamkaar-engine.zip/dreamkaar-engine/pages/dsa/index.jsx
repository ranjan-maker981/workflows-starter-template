import { useState, useEffect } from 'react';
import Layout from '../../components/Layout';
import { StatCard, BarChartWidget, PieChartWidget } from '../../components/Charts';
export default function DSADashboard() {
const [stats, setStats] = useState({});
const [loading, setLoading] = useState(true);
useEffect(() => {
fetch('/api/dsa/dashboard').then(r => r.json()).then(d => { setStats(d); setLoading(false); });
}, []);
if (loading) return <Layout title="DSA Dashboard"><div className="animate-pulse">Loading...</div></Layout>;
return (
<Layout title="DSA Dashboard">
<div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
<StatCard icon="👥" label="Total Leads" value={stats.totalLeads || 0} />
<StatCard icon="✅" label="Conversions" value={stats.conversions || 0} />
<StatCard icon="💰" label="Total Earned" value={`₹${(stats.totalEarned || 0).toLocaleString('en-IN')}`} />
<StatCard icon="⏳" label="Pending Payout" value={`₹${(stats.pendingPayout || 0).toLocaleString('en-IN')}`} />
</div>
<div className="grid md:grid-cols-2 gap-6 mb-6">
<BarChartWidget title="My Leads by Status" data={stats.leadsByStatus || []} xKey="status" yKey="count" />
<div className="card">
<h3 className="text-sm font-semibold text-gray-600 mb-4">Recent Leads</h3>
{(stats.recentLeads || []).length === 0 ? (
<p className="text-gray-400 text-center py-8">No leads submitted yet</p>
) : (
<div className="space-y-3">
{(stats.recentLeads || []).map(l => (
<div key={l.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
<div>
<p className="text-sm font-medium">{l.customer_name}</p>
<p className="text-xs text-gray-400">{l.model_interest} • {l.customer_city}</p>
</div>
<span className={`badge ${
l.status === 'delivered' ? 'badge-success' :
l.status === 'lost' ? 'badge-danger' : 'badge-info'
}`} style={{textTransform:'capitalize'}}>{(l.status||'').replace(/_/g,' ')}</span>
</div>
))}
</div>
)}
</div>
</div>
</Layout>
);
}