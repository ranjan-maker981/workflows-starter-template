import { useState } from 'react';
import { useRouter } from 'next/router';
export default function DSARegister() {
const router = useRouter();
const [form, setForm] = useState({
name: '', phone: '', email: '', city: '', state: '',
aadhaar: '', pan: '', bank_name: '', bank_account: '', bank_ifsc: '',
specialization: 'pv',
});
const [submitting, setSubmitting] = useState(false);
const [done, setDone] = useState(false);
async function submit() {
setSubmitting(true);
const res = await fetch('/api/dsa/register', {
method: 'POST',
headers: { 'Content-Type': 'application/json' },
body: JSON.stringify(form),
});
if (res.ok) setDone(true);
setSubmitting(false);
}
if (done) return (
<div className="min-h-screen flex items-center justify-center bg-dk-light p-4">
<div className="card max-w-md text-center">
<div className="text-5xl mb-4">✅</div>
<h2 className="text-xl font-bold mb-2">Application Submitted!</h2>
<p className="text-gray-500">Your DSA application is under review. You'll be notified once approved.</p>
<button onClick={() => router.push('/login')} className="btn-primary mt-6">Go to Login</button>
</div>
</div>
);
return (
<div className="min-h-screen bg-dk-light flex items-center justify-center p-4">
<div className="card w-full max-w-2xl">
<div className="text-center mb-6">
<h1 className="text-2xl font-bold">Dream<span className="text-dk-primary">Kaar</span></h1>
<h2 className="text-lg font-semibold mt-2">DSA Partner Registration</h2>
<p className="text-sm text-gray-500">Join our network and earn commissions on every car sale</p>
</div>
<div className="grid md:grid-cols-2 gap-4">
<div><label className="label-field">Full Name *</label><input className="input-field" value={form.name} onChange={e=>setForm({...form,name:e.target.value})} /></div>
<div><label className="label-field">Phone *</label><input className="input-field" value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})} /></div>
<div><label className="label-field">Email</label><input className="input-field" type="email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})} /></div>
<div><label className="label-field">City *</label><input className="input-field" value={form.city} onChange={e=>setForm({...form,city:e.target.value})} /></div>
<div><label className="label-field">State</label><input className="input-field" value={form.state} onChange={e=>setForm({...form,state:e.target.value})} /></div>
<div><label className="label-field">Specialization</label>
<select className="select-field" value={form.specialization} onChange={e=>setForm({...form,specialization:e.target.value})}>
<option value="pv">Passenger Vehicles</option><option value="cv">Commercial Vehicles</option><option value="both">Both</option>
</select>
</div>
<div><label className="label-field">Aadhaar Number</label><input className="input-field" value={form.aadhaar} onChange={e=>setForm({...form,aadhaar:e.target.value})} /></div>
<div><label className="label-field">PAN Number</label><input className="input-field" value={form.pan} onChange={e=>setForm({...form,pan:e.target.value})} /></div>
<div><label className="label-field">Bank Name</label><input className="input-field" value={form.bank_name} onChange={e=>setForm({...form,bank_name:e.target.value})} /></div>
<div><label className="label-field">Account Number</label><input className="input-field" value={form.bank_account} onChange={e=>setForm({...form,bank_account:e.target.value})} /></div>
<div><label className="label-field">IFSC Code</label><input className="input-field" value={form.bank_ifsc} onChange={e=>setForm({...form,bank_ifsc:e.target.value})} /></div>
</div>
<div className="flex justify-end mt-6">
<button onClick={submit} disabled={submitting || !form.name || !form.phone || !form.city} className="btn-primary">
{submitting ? 'Submitting...' : 'Submit Application'}
</button>
</div>
</div>
</div>
);
}