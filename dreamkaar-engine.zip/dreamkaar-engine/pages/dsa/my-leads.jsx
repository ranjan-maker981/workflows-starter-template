import { useState, useEffect } from 'react';
import Layout from '../../components/Layout';
import DataTable from '../../components/DataTable';
export default function DSAMyLeads() {
const [leads, setLeads] = useState([]);
const [loading, setLoading] = useState(true);
useEffect(() => {
fetch('/api/leads').then(r => r.json()).then(d => { setLeads(d.leads || []); setLoading(false); });
}, []);
const columns = [
{ key: 'customer_name', label: 'Name', render: v => <span className="font-medium">{v}</span> },
{ key: 'customer_phone', label: 'Phone' },
{ key: 'model_interest', label: 'Model' },
{ key: 'customer_city', label: 'City' },
{ key: 'status', label: 'Status', render: v => <span className={`badge ${v==='delivered'?'badge-success':v==='lost'?'badge-danger':'badge-info'}`} style={{textTransform:'capitalize'}}>{(v||'').replace(/_/g,' ')}</span> },
{ key: 'created_at', label: 'Submitted', render: v => v ? new Date(v).toLocaleDateString('en-IN') : '-' },
];
return (
<Layout title="My Leads">
<DataTable columns={columns} data={leads} emptyMessage="No leads submitted yet. Submit your first lead!" />
</Layout>
);
}