import { useState } from 'react';
import Layout from '../../components/Layout';
import { useRouter } from 'next/router';
export default function DSASubmitLead() {
const router = useRouter();
const [form, setForm] = useState({
customer_name: '', customer_phone: '', customer_city: '',
model_interest: '', budget_min: '', budget_max: '',
finance_required: false, cibil_range: '', notes: '',
});
const [submitting, setSubmitting] = useState(false);
const [success, setSuccess] = useState(false);
async function submit() {
setSubmitting(true);
const res = await fetch('/api/leads', {
method: 'POST',
headers: { 'Content-Type': 'application/json' },
body: JSON.stringify({ ...form, source: 'dsa' }),
});
if (res.ok) {
setSuccess(true);
setForm({ customer_name: '', customer_phone: '', customer_city: '',
model_interest: '', budget_min: '', budget_max: '',
finance_required: false, cibil_range: '', notes: '' });
setTimeout(() => setSuccess(false), 3000);
}
setSubmitting(false);
}
return (
<Layout title="Submit New Lead">
{success && (
<div className="bg-green-50 border border-green-200 text-green-700 p-4 rounded-xl mb-6">
Lead submitted successfully! You can track it in "My Leads".
</div>
)}
<div className="card max-w-2xl">
<h3 className="text-lg font-semibold mb-6">New Customer Lead</h3>
<div className="grid md:grid-cols-2 gap-4">
<div>
<label className="label-field">Customer Name *</label>
<input className="input-field" value={form.customer_name}
onChange={e => setForm({ ...form, customer_name: e.target.value })} />
</div>
<div>
<label className="label-field">Phone *</label>
<input className="input-field" type="tel" value={form.customer_phone}
onChange={e => setForm({ ...form, customer_phone: e.target.value })} />
</div>
<div>
<label className="label-field">City</label>
<input className="input-field" value={form.customer_city}
onChange={e => setForm({ ...form, customer_city: e.target.value })} />
</div>
<div>
<label className="label-field">Model Interest</label>
<input className="input-field" placeholder="e.g. Hyundai Creta" value={form.model_interest}
onChange={e => setForm({ ...form, model_interest: e.target.value })} />
</div>
<div>
<label className="label-field">Budget Min (₹)</label>
<input className="input-field" type="number" value={form.budget_min}
onChange={e => setForm({ ...form, budget_min: e.target.value })} />
</div>
<div>
<label className="label-field">Budget Max (₹)</label>
<input className="input-field" type="number" value={form.budget_max}
onChange={e => setForm({ ...form, budget_max: e.target.value })} />
</div>
<div>
<label className="label-field">CIBIL Range (if known)</label>
<select className="select-field" value={form.cibil_range}
onChange={e => setForm({ ...form, cibil_range: e.target.value })}>
<option value="">Unknown</option>
<option value="750+">750+ (Excellent)</option>
<option value="700-749">700-749 (Good)</option>
<option value="650-699">650-699 (Fair)</option>
<option value="600-649">600-649 (Poor)</option>
<option value="below-600">Below 600 (Very Poor)</option>
</select>
</div>
<div className="flex items-center gap-2 pt-6">
give giving next till project end
Continuing from File 50 onwards. I'll keep going until the full project is delivered.